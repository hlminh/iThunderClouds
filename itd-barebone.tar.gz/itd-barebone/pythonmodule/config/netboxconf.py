import getopt, sys
from optparse import OptionParser
from config import Config
from types import *

CONF_FILE = "/home/nm/tmp/config/msg.cfg"

f = file(CONF_FILE)
cfg = Config(f)

def list_all_item():
	return ""

def get_item(item):
	try:
		ret = cfg.getByPath(item)
	except :
		print "Can't get item " +  item
		exit(1)

	return ret 

def set_item(items, vals):
	i = 0 
	entries = items.split('.')

	v = cfg
	while i < len(entries) -1:		
		#print v
		v = getattr(v, entries[i])
		i += 1

	setattr(v, entries[ i ], vals)
	fsave = file(CONF_FILE, "w")
	cfg.save(fsave)
	return True

def main():
	usage = "usage: %prog command [item]"
	parser = OptionParser(usage=usage)
	parser.add_option("-g", "--get", action="store", type="string",  dest="get_item", metavar="ITEM" , default="", help="Get value of specific item")
	parser.add_option("-s", "--set", action="store", type="string",  dest="set_item", metavar="ITEM VALUE", default="", help="Set value of specific item")
	parser.add_option("-l", "--list", action="store_true",  dest="isListing", default=False, help="List all item with its value")

	if len(sys.argv) == 1:
		parser.print_help()
		exit(1)
	else:
		(options, args) = parser.parse_args()
#		print options 
#		print args 

		if (not options.get_item is ""):
			print get_item( options.get_item )

		elif (not options.set_item is ""):
			if len(args) == 0:
				parser.print_help()
				exit (1)			
			set_item( options.set_item, args[0] )

		elif options.isListing:
			list_all_item()
		else:
			parser.print_help()

		exit (0)

if __name__ == "__main__":
    main()

