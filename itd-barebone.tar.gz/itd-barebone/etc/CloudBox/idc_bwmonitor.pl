#!/usr/bin/perl

use strict;
use warnings;

use threads;

use XML::LibXML;
use File::Path qw(mkpath);
use Net::LDAP;
use Time::HiRes qw(gettimeofday);

#sudo aptitude install libxml-libxml-perl
#*/5 * * * * /export/BandwidthMonitoring14.pl

#Global variable

our $DEBUG = "True";
our $ROOT_PATH = "/tmp/public";

our $standard_1Gbps = 1073741824; #2^10 x 2^10 

our @ip_Arr;
our $ipMonitor = "119.15.169.113 %CloudBox{cloudbox.monitor.iplist}%";
@ip_Arr = split(' ', $ipMonitor);

our $format="k";
our $hostID = "%CloudBox{cloudbox.general.hostID}%";

our $domainCloud;
our $path_directory;
our $path_time;

############################
sub trim($) {
    my $string = shift;
    $string =~ s/^\s+//;
    $string =~ s/\s+$//;
    return $string;
}

############################
###Start check condition ###
sub prepare_Check
{
	my ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);
	$Year += 1900;
	$Month = sprintf '%02d', $Month+1;
	$Day   = sprintf '%02d', $Day;
	$path_time = "$Year/$Month/$Day";
	$path_directory = "$ROOT_PATH/$Year/$Month/$Day";

	if(!-d "$path_directory") 
	{
		mkpath("$path_directory", { verbose => 1, mode => 0751 });
	}
	else
	{
		print "the directory is exists $path_directory \n";
	}

}

### Create document ####
sub monitor_measure
{
	my $ip_Des=0;
	my $port_dest=5001;
	my $idsensor_dest=0;
	my $secretsensor_dest;

	for $ip_Des( @ip_Arr ) {
		my @return = ping_value($ip_Des, '5');
		if ($DEBUG){
			print "bandwidth do duoc: " . $return[2] . "\n";
		}

		#my $time_create = time();
		my $check_time = gettimeofday();
		my $time_create = int($check_time*1000);

		my $doc = XML::LibXML::Document->new( '1.0', 'UTF-8' );

		my $BW = $doc->createElement('BWMonitor');
		$doc->setDocumentElement( $BW );

		my $hostname = $doc->createElement ('HOST');
		$hostname->addChild($doc->createTextNode($hostID));
		$BW->addChild($hostname);

		my $time_element  = $doc->createElement('TIME');
		# Add a 'kind=' attribute to the 'TIME' clone
		$time_element->addChild($doc->createAttribute( "kind", "Unix Time Miliseconds" ) );
		# Add content to node
		$time_element->addChild($doc->createTextNode($check_time));
		# Add a 'TIME' child node under Data
		$BW->addChild( $time_element );

		#$time_create = $idsensor_dest . "_" . $time_create;
		my $ipDes = $return[1];
		if ($DEBUG){
			print $time_create . "\n";
			print "lalallaladkdkdkkd\n";
			print $ipDes . " : " . $port_dest . " format: " . $format . "port : " . $port_dest . "\n";
			print "lalallaladkdkdkkd\n\n";
		}
		my $info = `iperf -y C -f $format -c $ipDes -p $port_dest`;

		if ($DEBUG){
			print "return value: $info \n";
		}
		if ($info eq ""){
			print "nothing to do: $info \n";
		}
		my ($time_check,$ip_source,$port_source,$ip_dest,$port_dest1,$seq_num,$time_interver,$transfer,$bandwidth) = split(',', $info);

		#my $data = $doc->createElement('Data');
		#$data->addChild($doc->createAttribute ( IPDestination => $ip_Des) );
		#$BW->addChild($data);

		my $HostDestination = $doc->createElement ('HOSTDESTINATION');
		$HostDestination->addChild($doc->createTextNode($ip_Des));
		$BW->addChild($HostDestination);

		my $IPDestination = $doc->createElement ('IPDESTINATION');
		$IPDestination->addChild($doc->createTextNode($ipDes));
		$BW->addChild($IPDestination);

		if ($return[2] eq "False"){
			my $Timelive = $doc->createElement ('TIMELIVE');
			$Timelive->addChild($doc->createTextNode("Unknown Host"));
			$BW->addChild($Timelive);
		} else {
			my $Timelive = $doc->createElement ('TIMELIVE');
			$Timelive->addChild($doc->createTextNode($return[2]));
			$BW->addChild($Timelive);
		}
		my $bandwidth_element = $doc->createElement ('BANDWIDTH');
		my $units;

		if ($format eq "k") {
			$units = "Kbits";
		}
		elsif ($format eq "m") {
			$units = "Mbits";
		}
		elsif ($format eq "K") {
			$units = "KBytes";
		}
		elsif ($format eq "M") {
			$units = "KBytes";
		}
		else {
			$units = "Kbits";
		}

		if ($info eq ""){
			$bandwidth = "Connection refused";
		} else {
			$bandwidth = trim($bandwidth);
			if ($DEBUG){
				print "bandwidth do duoc: " . $bandwidth . "\n";
			}
			if ( $bandwidth > $standard_1Gbps ) {
				if ($DEBUG){
					print "so lon hon 1Gbps\n";
				}
				$bandwidth = "Error";
			}
		}
		
		$bandwidth_element->addChild($doc->createAttribute ( type => $units) );
		$bandwidth_element->addChild($doc->createTextNode($bandwidth));
		$BW->addChild($bandwidth_element);
		
		### start write data to File ###
		my $filenameXML = $hostID."_".$time_create.".xml";
		my $state = $doc->toFile("$path_directory/$filenameXML", 2);

		#import data to personal cloud
		#push_data_toCloud($idsensor_dest, $time_create, $secretsensor_dest);
		push_data_toCloud_Rsync("$path_directory/$filenameXML");
	}

}
sub push_data_toCloud_Rsync
{
	my $filenamePush = shift;

	system("export RSYNC_PASSWORD='openlab116';/usr/bin/rsync -au --no-group $filenamePush rsync://local\@localhost/BigData/BWMonitor/$path_time");
	system("export RSYNC_PASSWORD='openlab116';/usr/bin/rsync -au --no-group $filenamePush rsync://local\@119.15.169.113/BigData/BWMonitor/$path_time");
	system("rm $filenamePush");
}

sub push_data_toCloud
{
	#($username, $time_create, $secret) = @_;
	my $username = shift;
	my $time_create = shift;
	my $secret = shift;

	my ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time);
	$Year += 1900;
	$Month = sprintf '%02d', $Month+1;
	$Day   = sprintf '%02d', $Day;

	#print "user to connect cloud: ". $username . " file to put: " .$time_create . " domain: " .$domainCloud . "\n";
	#my $secret=eval(`/usr/bin/ldapsearch -h localhost -LLL -x -w openlab -D 'cn=proxyuser,dc=$boxID,dc=idragon,dc=vn' -b 'dc=$boxID,dc=idragon,dc=vn' 'uid=$username' | grep initials: | cut -d ':' -f2 | sed -e 's/ //g'`);
	#system("/usr/bin/smbclient //$boxID.idragon.vn/$username -p 1445 -D /Banwidth/$Year/$Month/$Day -U $domainCloud/$username%$secret -c 'lcd $path_directory; put $time_create.xml'");
	#system("/usr/bin/smbclient //$boxID.idragon.vn/$username -p 1445 -U $domainCloud/$username%$secret -c 'mkdir /bandwidth; mkdir /bandwidth/$Year; mkdir /bandwidth/$Year/$Month; mkdir /bandwidth/$Year/$Month/$Day; cd /bandwidth/$Year/$Month/$Day; lcd $path_directory; put $time_create.xml'");
	system("/usr/bin/smbclient //localhost/$username -p 1445 -U $domainCloud/$username%$secret -c 'mkdir /bandwidth; mkdir /bandwidth/$Year; mkdir /bandwidth/$Year/$Month; mkdir /bandwidth/$Year/$Month/$Day; cd /bandwidth/$Year/$Month/$Day; lcd $path_directory; put $time_create.xml'");
	system("rm $path_directory/$time_create.xml");
}

sub convertIP
{
	my ($host)=@_;
	print "converIP: ip host $host\n";
	#my $lookup = `ping -c1 -n $host | head -n1 | sed "s/.*(\([0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\)).*/\1/g"`;
	my $lookup = `ping -c1 -n $host | head -n1`;

	if (length($lookup) == 0){
		print "no value ping\n";
		return "False";
	} else {
		my $ip_convert;
		while ($lookup=~ /(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/g) {
			$ip_convert = $1;
			print $1;
			print "\n";
		}
		print "converIP: $lookup \n";
		print "converIP: $ip_convert \n";
		return $ip_convert;
	}
}

sub ping_value{
	my ($host, $pingcount) = @_;

	if (@_ != 2) {
		print "WARNING! ping_value should get exactly two arguments!\n";
	}

	#my $pingcount = '5';
	#my $host = '172.17.17.1';
	#my $host = 'box118a.idragon.vn';

	my $server = convertIP($host);
	print ">>>>> $server \n";
	if ($server eq "False") {
		print "ping false\n";
		my @return_array;
		$return_array[0] = $host;
		$return_array[1] = $server;
		$return_array[2] = 0;
		$return_array[3] = 0;
		return @return_array;
	} else {
	# lets start with the unix ping
	my $ping = `ping -c $pingcount $host`;

	# starts some variables
	my $rtt;
	my $loss;

	# check if the windows ping was run and therefore returned a Bad Value
	# error - if it did we're going to use the windows ping arguements
	if ( $ping =~ /Bad/ ) {
		$ping = `ping -n $pingcount $host`;

	# check for this word and grab it's value
		$ping =~ /Average = (.*)ms/;
		$rtt = $1;

	# check for the % sign inside parens and grab it's value
		$ping =~ /(\d*)%/;
		$loss = $1;
	} else {

	# unix ping has it's values separated by /s
		$ping =~ /\/(\d*\.\d*)\//;
		$rtt = $1;
	# same as windows ping... value is in parens
		$ping =~ /(\d*)%/;
		$loss = $1;
	}

	#print the values
	print "\n Host: $host have IP: $server time live average: " . $rtt . " percent loss package: " . $loss . "\n";

	my @return_array;
	$return_array[0] = $host;
	$return_array[1] = $server;
	$return_array[2] = $rtt;
	$return_array[3] = $loss;
	return @return_array;
	}

}

###call function here###

#$username = $ENV{LOGNAME} || $ENV{USER} || getpwuid($<);
#print $username;

prepare_Check();
#get_all_idSensor();
monitor_measure();

exit 0;

