#!/usr/bin/perl
####################################################################
# iThunderClouds Software
# Copyright (C) 2015 by Thien Minh Management JS Co. All Rights Reserved.
# Creator: Hoang Le Minh <leminh@thienminhmanagement>
# Version: 4.0
# Last updated: 16/07/2015
####################################################################
use Net::LDAP;
my $boxID = "%CloudBox{cloudbox.general.boxID}%";
my $base = "%CloudBox{cloudbox.general.base}%";
my $baseID = "%CloudBox{cloudbox.general.baseID}%";
my $ldapserver = "127.0.0.1:389";
my $grpbase = "ou=Groups,dc=box$boxID,$base";
my $usrbase = "ou=Users,dc=box$boxID,$base";
my $ldapuser = "cn=proxyuser,dc=box$boxID,$base";
my $ldappwd = "openlab";
my $grpattrs = ["cn","iDCloudPrimaryType","iDCloudPrimaryMember","confirmtext"];
my $usrattrs = ["dn","accountStatus",""];

my $ldap  = Net::LDAP -> new($ldapserver) || die "$@";
my $mesg = $ldap -> bind( $ldapuser, password => $ldappwd );

my $clgserver = "127.0.0.1:10389";
my $clgbase = "ou=Devices,ou=Clouds,$base";
my $clguser = "cn=proxyuser,ou=Admins,$base";
my $clgpwd = "openlab9002";
my $clgattrs = ["uid","iDDevicePrimaryContactURI"];

my $clg  = Net::LDAP -> new($clgserver) || die "$@";
my $clgmesg = $clg -> bind( $clguser, password => $clgpwd );

# Public clouds
my $public_clouds_backup = "%CloudBox{cloudbox.network.public_clouds_backup}%";
my @public_clouds_backup_list = split(/,/,$public_clouds_backup);
foreach my $cl (@public_clouds_backup_list) {
    my ($cname,$cid) = split(/:/,$cl);
    my $clgfilter = "uid=$cid";
    $clgmesg = $clg -> search(
	base => $clgbase,
	scope => "one",
	filter => $clgfilter,
	attrs => $clgattrs
    );
    $clgmesg -> code && die $clgmesg -> error;

    my $pubfilter = "(&(iDCloudStatus=Public)(cn=$cname))";
    $pubmesg = $ldap -> search(
	base => $grpbase,
	scope => "one",
	filter => $pubfilter,
	attrs => $grpattrs
    );
    $pubmesg -> code && die $pubmesg -> error;

    my @clgentries = $clgmesg -> all_entries;
    foreach my $entry (@clgentries) {
	my $do_rsync = "";
	my $backupbox = $entry -> get_value("iDDevicePrimaryContactURI");
	my ($bip,$bport) = split(":",$backupbox);
	print "Found backup databox ($backupbox) for $cname public cloud\n";

	my $check_rsync = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport $bip | grep -m 1 "$bport/tcp open");
	if ( "$check_rsync" ne "" ) {
	    $do_rsync = "OK";
	} else {
	    my $check_rsync_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport 127.0.0.1 | grep -m 1 "$bport/tcp open");
	    if ( "$check_rsync_ssh" ne "" ) {
		$backupbox = "127.0.0.1:$bport";
		$do_rsync = "OK";
	    } else {
		my $check_secure_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p 1022 $bip | grep "1022/tcp open");
		if ( "$check_secure_ssh" ne "" ) {
		    system("/bin/su local -c '/usr/bin/ssh -f -q -x -MN -O check -o ConnectTimeout=20 -p 1022 -L 127.0.0.1:$bport:127.0.0.1:$bport $bip'");
		} else {
		    my $check_server_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p 22 $bip | grep '22/tcp open');
		    if ( "$check_server_ssh" ne "" ) {
			system("/bin/su local -c '/usr/bin/ssh -f -q -x -MN -O check -o ConnectTimeout=20 -p 22 -L 127.0.0.1:$bport:127.0.0.1:$bport $bip'");
		    }
		}
		my $check_rsync_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport 127.0.0.1 | grep -m 1 "$bport/tcp open");
		if ( "$check_rsync_ssh" ne "" ) {
		    $backupbox = "127.0.0.1:$bport";
		    $do_rsync = "OK";
		}
	    }
	}

	if ( "$do_rsync" eq "OK" ) {
	    my @pubentries = $pubmesg -> all_entries;
	    foreach my $pentry (@pubentries) {
		my $cloud = $pentry -> get_value("cn");
		my $type = $pentry -> get_value("iDCloudPrimaryType");
		my $owner = $pentry -> get_value("iDCloudPrimaryMember");
		if ( "$type" eq "DigitalContents" ) {
		    $owner = "local";
		}
		my $syncpwd = $pentry -> get_value("confirmtext") || "openlab116";
		print "Trying backup $cloud public cloud (owner: $owner, password: $syncpwd)...\n";
		system("/bin/su $owner -c 'export RSYNC_PASSWORD=\"$syncpwd\";/usr/bin/rsync --partial -auv --progress --chmod=o=rX --no-g --exclude={.index/,.DAV/} /export/public/$cloud/. rsync://${backupbox}/$cloud'");
	    }
	} else {
	    print "Cannot find backup databox for $cloud public cloud\n";
	}
    }
}

# Private clouds
my $private_clouds_backup = "%CloudBox{cloudbox.network.private_clouds_backup}%";
my @private_clouds_backup_list = split(/,/,$private_clouds_backup);
foreach my $cl (@private_clouds_backup_list) {
    my ($cname,$cid) = split(/:/,$cl);
    my $clgfilter = "uid=$cid";
    $clgmesg = $clg -> search(
	base => $clgbase,
	scope => "one",
	filter => $clgfilter,
	attrs => $clgattrs
    );
    $clgmesg -> code && die $clgmesg -> error;

    my $prifilter = "(&(iDCloudStatus=Private)(cn=$cname))";
    $primesg = $ldap -> search(
	base => $grpbase,
	scope => "one",
	filter => $prifilter,
	attrs => $grpattrs
    );
    $primesg -> code && die $primesg -> error;

    my @clgentries = $clgmesg -> all_entries;
    foreach my $entry (@clgentries) {
	my $do_rsync = "";
	my $backupbox = $entry -> get_value("iDDevicePrimaryContactURI");
	my ($bip,$bport) = split(":",$backupbox);
	print "Found backup databox ($backupbox) for $cname private cloud\n";

	my $check_rsync = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport $bip | grep -m 1 "$bport/tcp open");
	if ( "$check_rsync" ne "" ) {
	    $do_rsync = "OK";
	} else {
	    my $check_rsync_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport 127.0.0.1 | grep -m 1 "$bport/tcp open");
	    if ( "$check_rsync_ssh" ne "" ) {
		$backupbox = "127.0.0.1:$bport";
		$do_rsync = "OK";
	    } else {
		my $check_secure_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p 1022 $bip | grep '1022/tcp open');
		if ( "$check_secure_ssh" ne "" ) {
		    system("/bin/su local -c '/usr/bin/ssh -f -q -x -MN -O check -o ConnectTimeout=20 -p 1022 -L 127.0.0.1:$bport:127.0.0.1:$bport $bip'");
		} else {
		    my $check_server_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p 22 $bip | grep '22/tcp open');
		    if ( "$check_server_ssh" ne "" ) {
			system("/bin/su local -c '/usr/bin/ssh -f -q -x -MN -O check -o ConnectTimeout=20 -p 22 -L 127.0.0.1:$bport:127.0.0.1:$bport $bip'");
		    }
		}
		my $check_rsync_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport 127.0.0.1 | grep -m 1 "$bport/tcp open");
		if ( "$check_rsync_ssh" ne "" ) {
		    $backupbox = "127.0.0.1:$bport";
		    $do_rsync = "OK";
		}
	    }
	}

	if ( "$do_rsync" eq "OK" ) {
	    my @prientries = $primesg -> all_entries;
	    foreach my $pentry (@prientries) {
		my $cloud = $pentry -> get_value("cn");
		my $owner = $pentry -> get_value("iDCloudPrimaryMember");
		my $syncpwd = $pentry -> get_value("confirmtext") || "openlab116";
		print "Trying backup $cloud private cloud (owner: $owner, password: $syncpwd)...\n";
		system("/bin/su $owner -c 'export RSYNC_PASSWORD=\"$syncpwd\";/usr/bin/rsync --partial -auv --progress --chmod=o=rX --no-g --exclude={.index/,.DAV/} /export/private/$cloud/. rsync://${backupbox}/$cloud'");
	    }
	} else {
	    print "Cannot find backup databox for $cloud private cloud\n";
	}
    }
}

# Personal clouds
my $personal_clouds_backup = "%CloudBox{cloudbox.network.personal_clouds_backup}%";
my @personal_clouds_backup_list = split(/,/,$personal_clouds_backup);
foreach my $cl (@personal_clouds_backup_list) {
    my ($cname,$cid) = split(/:/,$cl);
    my $clgfilter = "uid=$cid";
    $clgmesg = $clg -> search(
	base => $clgbase,
	scope => "one",
	filter => $clgfilter,
	attrs => $clgattrs
    );
    $clgmesg -> code && die $clgmesg -> error;

    my $perfilter = "(&(!(accountStatus=template))(uid=$cname))";
    my $permesg = $ldap -> search(
	base => $usrbase,
	scope => "one",
	filter => $perfilter,
	attrs => $usrattrs
	);
    $permesg -> code && die $permesg -> error;

    my @clgentries = $clgmesg -> all_entries;
    foreach my $entry (@clgentries) {
	my $do_rsync = "";
	my $backupbox = $entry -> get_value("iDDevicePrimaryContactURI");
	my ($bip,$bport) = split(":",$backupbox);
	print "Found backup databox ($backupbox) for $cname personal cloud\n";

	my $check_rsync = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport $bip | grep "$bport/tcp open");
	if ( "$check_rsync" ne "" ) {
	    $do_rsync = "OK";
	} else {
	    my $check_rsync_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport 127.0.0.1 | grep "$bport/tcp open");
	    if ( "$check_rsync_ssh" ne "" ) {
		$backupbox = "127.0.0.1:$bport";
		$do_rsync = "OK";
	    } else {
		my $check_secure_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p 1022 $bip | grep '1022/tcp open');
		if ( "$check_secure_ssh" ne "" ) {
		    system("/bin/su local -c '/usr/bin/ssh -f -q -x -MN -O check -o ConnectTimeout=20 -p 1022 -L 127.0.0.1:$bport:127.0.0.1:$bport $bip'");
		} else {
		    my $check_server_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p 22 $bip | grep '22/tcp open');
		    if ( "$check_server_ssh" ne "" ) {
			system("/bin/su local -c '/usr/bin/ssh -f -q -x -MN -O check -o ConnectTimeout=20 -p 22 -L 127.0.0.1:$bport:127.0.0.1:$bport $bip'");
		    }
		}
		my $check_rsync_ssh = qx(/usr/bin/nmap -Pn -n --host_timeout 201 -p $bport 127.0.0.1 | grep "$bport/tcp open");
		if ( "$check_rsync_ssh" ne "" ) {
		    $backupbox = "127.0.0.1:$bport";
		    $do_rsync = "OK";
		}
	    }
	}

	if ( "$do_rsync" eq "OK" ) {
	    my @perentries = $permesg -> all_entries;
	    foreach my $pentry (@perentries) {
		my $userDN = $pentry -> dn;
		my $status = "";
		my @ous = $pentry -> get_value("ou");
		foreach my $st ( @ous ) {
		    if ( $st =~ /active|sensor/ ) {
			$status = "active";
			last;
		    }
		}
		my ($dnstr,$basestr) = split(/,/,$userDN);
		my ($dn,$cloud) = split(/=/,$dnstr);
		print "Trying backup $cloud personal cloud...\n";
		if ( $status eq "active" ) {
		    system("/bin/su $cloud -c 'export RSYNC_PASSWORD=\"openlab116\";/usr/bin/rsync --partial -auv --progress --chmod=o=rX --no-g --exclude={.index/,.DAV/} /export/users/$cloud/. rsync://${backupbox}/$cloud'");
		} else {
		    system("/bin/su $cloud -c 'export RSYNC_PASSWORD=\"openlab116\";/usr/bin/rsync --partial -auv --progress --chmod=o=rX --no-g --exclude={.index/,.DAV/} /export/users/$cloud/iDragonCloud/. rsync://${backupbox}/$cloud/iDragonCloud'");
		}
	    }
	} else {
	    print "Cannot find backup databox for $cloud personal cloud\n";
	}
    }
}

$mesg = $ldap -> unbind;
exit 0;
