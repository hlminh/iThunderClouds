#!/usr/bin/perl
####################################################################
# iThunderClouds Software
# Copyright (C) 2014-2017 by Thien Minh Management JS Co. All Rights Reserved.
# Creator: Hoang Le Minh <hlminh@cloudgate.vn>
# Version: 9.1
# Last updated: 09 Jan 2017
####################################################################
use Net::LDAP;
my $base = "%CloudBox{cloudbox.general.base}%";
my $boxID = "%CloudBox{cloudbox.general.boxID}%";
my $baseID = "%CloudBox{cloudbox.general.baseID}%";
my $hostID = "%CloudBox{cloudbox.general.hostID}%";
my $domainID = "%CloudBox{cloudbox.general.domainID}%";
my $sambaDomain = "%CloudBox{cloudbox.samba.workgroup}%";
my $usenfs = "%CloudBox{cloudbox.network.usenfs}%";
my $useautofs = "%CloudBox{cloudbox.network.useautofs}%";
my $nfslocal = "%CloudBox{cloudbox.network.nfslocal}%";
my $ldapserver = "127.0.0.1:10389";
my $grpbase = "ou=Groups,$baseID";
my $usrbase = "ou=Users,$baseID";
my $ldapuser = "cn=manager,$base";
my $ldappwd = "openlab8002";
my $ldap  = Net::LDAP -> new($ldapserver) || die "$@";
my $mesg = $ldap -> bind($ldapuser, password => $ldappwd);

my $grpfilter = "(&(objectClass=posixGroup)(bounceadmin=$sambaDomain))";
my $grpattrs = ["cn","gidNumber"];
$mesg = $ldap -> search(
    base => $grpbase,
    scope => "one",
    filter => $grpfilter,
    attrs => $grpattrs
    );

$mesg -> code && die $mesg -> error;
my @grpentries = $mesg -> all_entries;
my %group_name;

foreach my $entry (@grpentries) {
    my $gidnum = $entry -> get_value("gidNumber");
    my $gname = $entry -> get_value("cn");
    $group_name{$gidnum} = $gname;
}

# Making WebDAV support for Public / proxying to Private/Personal Clouds
if ( "%CloudBox{cloudbox.network.webdav_server}%" eq "yes" ) {
    open(DAV,"> /etc/apache2/conf-available/data.conf");
    #print DAV "<VirtualHost _default_:80>\n";
    #print DAV "\tServerName $hostID.$domainID\n";
    #print DAV "\tServerAdmin support\@$domainID\n";
    #print DAV "\tCustomLog \${APACHE_LOG_DIR}/access.log combined\n";
    #print DAV "\tErrorLog \${APACHE_LOG_DIR}/error.log\n";
    print DAV "\tScriptAlias /bin/ /etc/itd/bin/\n";
    print DAV "\t<Directory \"/etc/itd/bin/\">\n";
    print DAV "\t\tAllowOverride None\n";
    print DAV "\t\tOptions +ExecCGI -MultiViews +SymLinksIfOwnerMatch\n";
    #print DAV "\t\tRequire host localhost\n";
    #print DAV "\t\tRequire ip 172.17\n";
    print DAV "\t\tRequire all granted\n";
    print DAV "\t</Directory>\n";
    print DAV "\n";
    print DAV "\tDavLockDB /var/lock/apache2/DavLock\n";
    close(DAV);
    system("[ ! -L /etc/apache2/conf-enabled/data.conf ] && /bin/ln -s /etc/apache2/conf-available/data.conf /etc/apache2/conf-enabled/data.conf");
}

system("/bin/cp -f /etc/itd/template/rsync/rsyncd.conf /etc/itd/template");
system("/bin/cp -f /etc/itd/template/rsync/rsyncd.secrets /etc/itd/template");
open(RSN,">> /etc/itd/template/rsyncd.conf");
open(PWD,">> /etc/itd/template/rsyncd.secrets");

# Making Private Clouds
my $prifilter;
my $private_clouds = "%CloudBox{cloudbox.network.private_clouds}%";
if ( $private_clouds ne "" ) {
    my @private_clouds_list = split(/,/,$private_clouds);
    my @pricl;
    foreach my $cl (@private_clouds_list) {
	push(@pricl,"(cn=$cl)");
    }
    my $priflt_cl = "|(iDCloudPrimaryProviderURI=$hostID)(iDCloudSecondaryProviderURI=$hostID)(iDCloudBackupProviderURI=$hostID)";
    foreach my $fcl (@pricl) {
	$priflt_cl .= $fcl;
    }
    $prifilter = "(&(iDCloudStatus=Private)(bounceadmin=$sambaDomain)($priflt_cl))";
} else {
    $prifilter = "(&(iDCloudStatus=Private)(bounceadmin=$sambaDomain)(|(iDCloudPrimaryProviderURI=$hostID)(iDCloudSecondaryProviderURI=$hostID)(iDCloudBackupProviderURI=$hostID)))";
}
my $priattrs = ["gidNumber","cn","iDCloudName","iDCloudPrimaryMember","iDCloudPrimaryProviderURI","iDCloudSecondaryProviderURI","iDCloudBackupProviderURI","iDCloudPrimaryType","bounceadmin"];
$mesg = $ldap -> search(
    base => $grpbase,
    scope => "one",
    filter => $prifilter,
    attrs => $priattrs
);

$mesg -> code && die $mesg -> error;
my @prientries = $mesg -> all_entries;

my @idc_private_clouds;

foreach my $entry (@prientries) {
    my $cloud = $entry -> get_value("cn");
    my $comment = $entry -> get_value("iDCloudName");
    my $owner = $entry -> get_value("iDCloudPrimaryMember");
    my $rsyncpwd = $entry -> get_value("confirmtext") || "openlab116";
    my $gid = $entry -> get_value("gidNumber");
    my $dav_port = $gid - $boxID*10000;
    my $pridav_port = $dav_port*2 + 1001;
    my $type = $entry -> get_value("iDCloudPrimaryType");

    print "Preparing private cloud $cloud\n";
    if ( "$useautofs" eq "yes" ) {
	system("/bin/ls /export/private/$cloud");
    }
    my $sudocmd = ""; 
    if ( "$usenfs" eq "yes" && $nfslocal =~ /private\/$cloud/ ) {
	$sudocmd = "/usr/bin/sudo -u $owner";
    }
    system("$sudocmd /bin/mkdir -p /export/private/$cloud");
    if ( $type eq "DigitalContents" ) {
	if ( ! -e "/export/private/$cloud/repository.xml" ) {
	    system("$sudocmd /bin/cp -f /etc/itd/template/ddrstore/repository.xml /export/private/$cloud/repository.xml");
	}
	system("$sudocmd /bin/mkdir -p /export/private/$cloud/Temporary;$sudocmd /bin/cp -rn /etc/itd/template/ddrstore/Temporary/. /export/private/$cloud/Temporary");
	system("$sudocmd /bin/mkdir -p /export/private/$cloud/Main;$sudocmd /bin/cp -rn /etc/itd/template/ddrstore/Main/. /export/private/$cloud/Main");
    }
    system("$sudocmd /bin/chmod 0770 /export/private/$cloud");
    #system("$sudocmd /bin/chgrp -R $cloud /export/private/$cloud");
    system("$sudocmd /bin/chown $owner:$cloud /export/private/$cloud");

    print RSN "[$cloud]\n";
    print RSN "comment = $comment\n";
    print RSN "path = /export/private/$cloud\n";
    print RSN "use chroot = yes\n";
    print RSN "max connections = 5\n";
    print RSN "lock file = /var/lock/rsyncd-$cloud\n";
    print RSN "read only = no\n";
    print RSN "list = yes\n";
    print RSN "uid = $owner\n";
    print RSN "gid = $cloud\n";
    print RSN "auth users = $owner\n";
    print RSN "secrets file = /etc/rsyncd.secrets\n";
    print RSN "strict modes = yes\n";
    print RSN "hosts allow = 127.0.0.1 172.17.17.0/24 %CloudBox{cloudbox.network.private_allowIP}% \n";
    print RSN "ignore errors = no\n";
    print RSN "ignore nonreadable = yes\n";
    print RSN "transfer logging = no\n";
    print RSN "log format = %t: host %h \(%a\) %o %f \(%l bytes\). Total %b bytes.\n";
    print RSN "timeout = 600\n";
    print RSN "refuse options = checksum dry-run\n";
    print RSN "dont compress = *.gz *.tgz *.zip *.z *.rpm *.deb *.iso *.bz2 *.tbz\n";
    print RSN "\n";
    print PWD "$owner:$rsyncpwd\n";

    if ( "%CloudBox{cloudbox.network.webdav_server}%" eq "yes" && "%CloudBox{cloudbox.network.private_webdav_server}%" eq "yes" ) {
	system("/bin/rm -rf /etc/apache2-$pridav_port");
	system("/bin/cp -af /etc/apache2 /etc/apache2-$pridav_port");
	system("/bin/rm -f /etc/init.d/apache2-$pridav_port");
	#system("/bin/ln -fs /etc/init.d/apache2 /etc/init.d/apache2-$pridav_port");
	system("/bin/cp -af /etc/init.d/apache2 /etc/init.d/apache2-$pridav_port");
	system("/bin/chmod 755 /etc/init.d/apache2-$pridav_port");
	system("/bin/systemctl enable apache2-$pridav_port");
	system("/bin/cp -af /etc/logrotate.d/apache2 /etc/logrotate.d/apache2-$pridav_port");
	system("/bin/sed -e s/apache2/apache2-$pridav_port/g -i /etc/logrotate.d/apache2-$pridav_port");
	system("/bin/mkdir -p /var/log/apache2-$pridav_port;chmod 750 /var/log/apache2-$pridav_port;chown root:adm /var/log/apache2-$pridav_port");
	system("[ ! -L /etc/apache2-$pridav_port/log ] && /bin/ln -s /var/log/apache2-$pridav_port /etc/apache2-$pridav_port/log");

	system("/bin/sed -e s/_default_/127.0.0.1/g -i /etc/apache2-$pridav_port/sites-available/000-default.conf");
	system("/bin/sed -e s/80/$pridav_port/g -i /etc/apache2-$pridav_port/sites-available/000-default.conf");
	system("/bin/sed -e 's|ScriptsAlias /bin/ |ScriptsAlias /$cloud/bin/ |' -i /etc/apache2-$pridav_port/sites-available/000-default.conf");
	system("/bin/sed -e 's|/var/lock/apache2/DavLock|/var/lock/apache2-$pridav_port/DavLock|' -i /etc/apache2-$pridav_port/sites-available/000-default.conf");

	open(PRIDAV,">>/etc/apache2-$pridav_port/sites-available/000-default.conf");
	print PRIDAV "\tAlias /$cloud/ /export/private/$cloud/\n";
	print PRIDAV "\tDavLockDB /var/lock/apache2-$pridav_port/DavLock\n";
	print PRIDAV "\t<Directory \"/export/private/$cloud/\">\n";
	print PRIDAV "\t\tAllowOverride None\n";
	print PRIDAV "\t\tRequire host localhost\n";
	#print PRIDAV "\t\tRequire ip 172.17\n";
	#print PRIDAV "\t\tRequire all granted\n";
	print PRIDAV "\t\tDAV On\n";
	print PRIDAV "\t</Directory>\n";
	print PRIDAV "\t<Location \"/$cloud/\">\n";
	print PRIDAV "\t\tSatisfy any\n";
	print PRIDAV "\t\tAuthType Basic\n";
	print PRIDAV "\t\tAuthName \"$comment\"\n";
	print PRIDAV "\t\tAuthBasicProvider ldap\n";
	print PRIDAV "\t\tAuthLDAPUrl \"ldap://localhost/ou=Users,$baseID?uid\"\n";
	print PRIDAV "\t\tAuthLDAPBindDN \"cn=proxyuser,$baseID\"\n";
	print PRIDAV "\t\tAuthLDAPBindPassword \"openlab\"\n";
	print PRIDAV "\t\tAuthLDAPGroupAttributeIsDN off\n";
	print PRIDAV "\t\tAuthLDAPGroupAttribute memberUid\n";
	print PRIDAV "\t\tRequire ldap-group cn=$cloud,ou=Groups,$baseID\n";
	print PRIDAV "\t</Location>\n";
	print PRIDAV "</VirtualHost>\n";
	close(PRIDAV);

	system("/bin/sed -e s/APACHE_RUN_USER=local/APACHE_RUN_USER=$owner/g -i /etc/apache2-$pridav_port/envvars");
	system("/bin/sed -e s/APACHE_RUN_GROUP=apache/APACHE_RUN_GROUP=$cloud/g -i /etc/apache2-$pridav_port/envvars");
	system("/bin/sed -e s/80/$pridav_port/g -i /etc/apache2-$pridav_port/ports.conf");
	system("/bin/mkdir -p /run/lock/apache2-$pridav_port");
	system("/bin/chown -R $owner:$cloud /run/lock/apache2-$pridav_port");
    }
}

# Making Personal Clouds
my $usrfilter;
my $usr_uids = "%CloudBox{cloudbox.network.personal_uids}%";
if ( $usr_uids ne "" ) {
    my @usr_uids_list = split(/,/,$usr_uids);
    my @usrcl;

    foreach my $cl (@usr_uids_list) {
	push(@usrcl,"(uid=$cl)");
    }

    my $usrflt_cl = "|(iDAccountPrimaryContactURI=$hostID)(iDAccountSecondaryContactURI=$hostID)(iDAccountBackupContactURI=$hostID)";
    foreach my $fcl (@usrcl) {
	$usrflt_cl .= $fcl;
    }
    $usrfilter = "(&(ou=$sambaDomain:*)($usrflt_cl))";
} else {
    $usrfilter = "(&(ou=$sambaDomain:*)(|(iDAccountPrimaryContactURI=$hostID)(iDAccountSecondaryContactURI=$hostID)(iDAccountBackupContactURI=$hostID)))";
}

my $usrattrs = ["uidNumber","gidNumber","iDAccountName","ou","uid","iDAccountPrimaryContactURI","iDAccountSecondaryContactURI","iDAccountBackupContactURI"];
$mesg = $ldap -> search(
    base => $usrbase,
    scope => "one",
    filter => $usrfilter,
    attrs => $usrattrs
);

$mesg -> code && die $mesg -> error;
my @usrentries = $mesg -> all_entries;

foreach my $entry (@usrentries) {
    my $userDN = $entry -> dn;
    my ($dnstr,$basestr) = split(",",$userDN);
    my ($dn,$cloud) = split("=",$dnstr);
    my $gid = $entry -> get_value("gidNumber");
    my $group = $group_name{$gid} || "apache";
    my $uid = $entry -> get_value("uidNumber");
    my $dav_port = $uid - $boxID*10000;
    my $perdav_port = $dav_port*2 + 1000;
    my $comment = $entry -> get_value("iDAccountName");

    print "Preparing personal cloud $uid\n";
    if ( "$useautofs" eq "yes" ) {
	system("/bin/ls /export/users/$uid");
    }
    my $sudocmd = ""; 
    if ( "$usenfs" eq "yes" && $nfslocal =~ /users\/$uid/ ) {
	$sudocmd = "/usr/bin/sudo -u $uid";
    }
    system("$sudocmd /bin/mkdir -p /export/users/$uid/iDragonCloud");
    system("$sudocmd /bin/chmod 0755 /export/users/$uid");

    print RSN "[$cloud]\n";
    print RSN "comment = $comment\n";
    print RSN "path = /export/users/$cloud\n";
    print RSN "use chroot = yes\n";
    print RSN "max connections = 1\n";
    print RSN "lock file = /var/lock/rsyncd-$cloud\n";
    print RSN "read only = no\n";
    print RSN "list = yes\n";

    my $check_st;
    my @ous = $entry -> get_value("ou");
    foreach my $st ( @ous ) {
	if ( $st =~ /active|sensor/ ) {
	    $check_st = "active";
	    last;
	}
    }

    system("/bin/mkdir -p /export/users/$cloud/iDragonCloud");
    if ( $check_st eq "active" ) {
	system("/bin/cp -rf /etc/itd/template/skel.users/. /export/users/$cloud");
	system("/bin/chown $cloud:$group /export/users/$cloud");
	print RSN "uid = $cloud\n";
	print RSN "gid = $group\n";
	print RSN "auth users = $cloud\n";
	print PWD "$cloud:openlab116\n";
    } else {
	system("/bin/chown local:apache /export/users/$cloud");
	print RSN "uid = local\n";
	print RSN "gid = apache\n";
	print RSN "auth users = local\n";
    }

    print RSN "secrets file = /etc/rsyncd.secrets\n";
    print RSN "strict modes = yes\n";
    print RSN "hosts allow = 127.0.0.1 172.17.17.0/24 %CloudBox{cloudbox.network.personal_allowIP}%\n";
    print RSN "ignore errors = no\n";
    print RSN "ignore nonreadable = yes\n";
    print RSN "transfer logging = no\n";
    print RSN "log format = %t: host %h \(%a\) %o %f \(%l bytes\). Total %b bytes.\n";
    print RSN "timeout = 600\n";
    print RSN "refuse options = checksum dry-run\n";
    print RSN "dont compress = *.gz *.tgz *.zip *.z *.rpm *.deb *.iso *.bz2 *.tbz\n";
    print RSN "incoming chmod = Fu=rw,Fog-rwx,Du=rwx,Dog-rwx\n";
    print RSN "\n";

    if ( "%CloudBox{cloudbox.network.webdav_server}%" eq "yes" && "%CloudBox{cloudbox.network.personal_webdav_server}%" eq "yes" ) {

	if ( $check_st eq "active" ) {
	    system("/bin/rm -rf /etc/apache2-$perdav_port");
	    system("/bin/cp -af /etc/apache2 /etc/apache2-$perdav_port");
	    system("/bin/rm -f /etc/init.d/apache2-$perdav_port");
	    #system("/bin/ln -fs /etc/init.d/apache2 /etc/init.d/apache2-$perdav_port");
	    system("/bin/cp -af /etc/init.d/apache2 /etc/init.d/apache2-$perdav_port");
	    system("/bin/chmod 755 /etc/init.d/apache2-$perdav_port");
	    system("/bin/systemctl enable apache2-$perdav_port");
	    system("/bin/cp -af /etc/logrotate.d/apache2 /etc/logrotate.d/apache2-$perdav_port");
	    system("/bin/sed -e s/apache2/apache2-$perdav_port/g -i /etc/logrotate.d/apache2-$perdav_port");
	    system("/bin/mkdir -p /var/log/apache2-$perdav_port;chmod 750 /var/log/apache2-$perdav_port;chown root:adm /var/log/apache2-$perdav_port");
	    system("[ ! -L /etc/apache2-$perdav_port/log ] && /bin/ln -s /var/log/apache2-$perdav_port /etc/apache2-$perdav_port/log");

	    system("/bin/sed -e s/_default_/127.0.0.1/g -i /etc/apache2-$perdav_port/sites-available/000-default.conf");
	    system("/bin/sed -e s/80/$perdav_port/g -i /etc/apache2-$perdav_port/sites-available/000-default.conf");
	    system("/bin/sed -e 's|ScriptsAlias /bin/ |ScriptsAlias /$cloud/bin/ |' -i /etc/apache2-$perdav_port/sites-available/000-default.conf");
	    system("/bin/sed -e 's|/var/lock/apache2/DavLock|/var/lock/apache2-$perdav_port/DavLock|' -i /etc/apache2-$perdav_port/sites-available/000-default.conf");

	    open(PERDAV,">> /etc/apache2-$perdav_port/sites-available/000-default.conf");
	    print PERDAV "\tAlias /$cloud/ /export/users/$cloud/iDragonCloud/\n";
	    print PERDAV "\tDavLockDB /var/lock/apache2-$perdav_port/DavLock\n";
	    print PERDAV "\t<Directory \"/export/users/$cloud/iDragonCloud/\">\n";
	    print PERDAV "\t\tAllowOverride None\n";
	    print PERDAV "\t\tRequire host localhost\n";
	    #print PERDAV "\t\tRequire ip 172.17\n";
	    #print PERDAV "\t\tRequire all granted\n";
	    print PERDAV "\t\tDAV On\n";
	    print PERDAV "\t</Directory>\n";
	    print PERDAV "\t<Location \"/$cloud/\">\n";
	    print PERDAV "\t\tSatisfy any\n";
	    print PERDAV "\t\tAuthType Basic\n";
	    print PERDAV "\t\tAuthName \"$comment\"\n";
	    print PERDAV "\t\tAuthBasicProvider ldap\n";
	    print PERDAV "\t\tAuthLDAPUrl \"ldap://localhost/ou=Users,$baseID?uid\"\n";
	    print PERDAV "\t\tAuthLDAPBindDN \"cn=proxyuser,$baseID\"\n";
	    print PERDAV "\t\tAuthLDAPBindPassword \"openlab\"\n";
	    print PERDAV "\t\tRequire ldap-user $cloud\n";
	    print PERDAV "\t</Location>\n";
	    print PERDAV "</VirtualHost>\n";
	    close(PERDAV);

	    system("/bin/sed -e s/APACHE_RUN_USER=local/APACHE_RUN_USER=$cloud/g -i /etc/apache2-$perdav_port/envvars");
	    system("/bin/sed -e s/APACHE_RUN_GROUP=apache/APACHE_RUN_GROUP=$group/g -i /etc/apache2-$perdav_port/envvars");
	    system("/bin/sed -e s/80/$perdav_port/g -i /etc/apache2-$perdav_port/ports.conf");
	    system("/bin/mkdir -p /run/lock/apache2-$perdav_port");
	    system("/bin/chown -R $cloud:$group /run/lock/apache2-$perdav_port");

	} else {

	    open(DAV,">> /etc/apache2/conf-available/data.conf");
	    #open(DAV,">> /etc/apache2/sites-available/000-default.conf");
	    print DAV "\tAlias /$cloud/ /export/users/$cloud/iDragonCloud/\n";
	    print DAV "\t<Directory \"/export/users/$cloud/iDragonCloud/\">\n";
	    print DAV "\t\tAllowOverride None\n";
	    #print DAV "\t\tRequire host localhost\n";
	    #print DAV "\t\tRequire ip 172.17\n";
	    print DAV "\t\tRequire all granted\n";
	    print DAV "\t\tDAV On\n";
	    print DAV "\t</Directory>\n";
	    print DAV "\t<Location \"/$cloud/\">\n";
	    print DAV "\t\tSatisfy any\n";
	    print DAV "\t\tAuthType Basic\n";
	    print DAV "\t\tAuthName \"$comment\"\n";
	    print DAV "\t\tAuthBasicProvider ldap\n";
	    print DAV "\t\tAuthLDAPUrl \"ldap://localhost/ou=Users,$baseID?uid\"\n";
	    print DAV "\t\tAuthLDAPBindDN \"cn=proxyuser,$baseID\"\n";
	    print DAV "\t\tAuthLDAPBindPassword \"openlab\"\n";
	    print DAV "\t\tRequire ldap-user $cloud\n";
	    print DAV "\t</Location>\n";
	    close(DAV);
	}
    }
}

# Making Public Clouds
my $pubfilter;
my $public_clouds = "%CloudBox{cloudbox.network.public_clouds}%";
if ( $public_clouds ne "" ) {
    my @public_clouds_list = split(/,/,$public_clouds);
    my @pubcl;
    foreach my $cl (@public_clouds_list) {
	push(@pubcl,"(cn=$cl)");
    }
    my $pubflt_cl = "|(iDCloudPrimaryProviderURI=$hostID)(iDCloudSecondaryProviderURI=$hostID)(iDCloudBackupProviderURI=$hostID)";
    foreach my $fcl (@pubcl) {
	$pubflt_cl .= $fcl;
    }
    $pubfilter = "(&(iDCloudStatus=Public)(bounceadmin=$sambaDomain)($pubflt_cl))";
} else {
    $pubfilter = "(&(iDCloudStatus=Public)(bounceadmin=$sambaDomain)(|(iDCloudPrimaryProviderURI=$hostID)(iDCloudSecondaryProviderURI=$hostID)(iDCloudBackupProviderURI=$hostID)))";
}
my $pubattrs = ["gidNumber","cn","iDCloudName","iDCloudPrimaryType","iDCloudPrimaryProviderURI","iDCloudSecondaryProviderURI","iDCloudBackupProviderURI","iDCloudPrimaryMember","iDCloudSecondaryMember","bounceadmin"];

$mesg = $ldap -> search(
    base => $grpbase,
    scope => "one",
    filter => $pubfilter,
    attrs => $pubattrs
);

$mesg -> code && die $mesg -> error;
my @pubentries = $mesg -> all_entries;

foreach my $entry (@pubentries) {
    my $cloud = $entry -> get_value("cn");
    my $comment = $entry -> get_value("iDCloudName");
    my $owner = $entry -> get_value("iDCloudPrimaryMember");
    my $rsyncpwd = $entry -> get_value("confirmtext") || "openlab116";
    my $type = $entry -> get_value("iDCloudPrimaryType");
    my $gid = $entry -> get_value("gidNumber");

    print "Preparing Public Cloud $cloud\n";
    if ( "$useautofs" eq "yes" ) {
	system("/bin/ls /export/public/$cloud");
    }
    my $sudocmd = ""; 
    if ( "$usenfs" eq "yes" && $nfslocal =~ /public\/$cloud/ ) {
	$sudocmd = "/usr/bin/sudo -u $owner";
    }
    system("$sudocmd /bin/mkdir -p /export/public/$cloud");
    system("$sudocmd /bin/chmod 0775 /export/public/$cloud");
    if ( $type eq "DigitalContents" ) {
	if ( ! -e "/export/public/$cloud/repository.xml" ) {
	    system("$sudocmd /bin/cp -f /etc/itd/template/ddrstore/repository.xml /export/public/$cloud/repository.xml");
	}
	system("$sudocmd /bin/mkdir -p /export/public/$cloud/Temporary;$sudocmd /bin/cp -rn /etc/itd/template/ddrstore/Temporary/. /export/public/$cloud/Temporary");
	system("$sudocmd /bin/mkdir -p /export/public/$cloud/Main;$sudocmd /bin/cp -rn /etc/itd/template/ddrstore/Main/. /export/public/$cloud/Main");
	system("$sudocmd /bin/chown local:$cloud /export/public/$cloud");
    } else {
	system("$sudocmd /bin/chown $owner:$cloud /export/public/$cloud");
    }

    print RSN "[$cloud]\n";
    print RSN "comment = $comment\n";
    print RSN "path = /export/public/$cloud\n";
    print RSN "use chroot = yes\n";
    print RSN "max connections = 5\n";
    print RSN "lock file = /var/lock/rsyncd-$cloud\n";
    print RSN "read only = no\n";
    print RSN "list = yes\n";
    if ( $type eq "DigitalContents" ) {
	print RSN "uid = local\n";
	print RSN "auth users = local\n";
	print PWD "local:$rsyncpwd\n";
    } else {
	print RSN "uid = $owner\n";
	print RSN "auth users = $owner\n";
	print PWD "$owner:$rsyncpwd\n";
    }
    print RSN "gid = $cloud\n";
    print RSN "secrets file = /etc/rsyncd.secrets\n";
    print RSN "strict modes = yes\n";
    print RSN "hosts allow = 127.0.0.1 172.17.17.0/24 %CloudBox{cloudbox.network.public_allowIP}%\n";
    print RSN "ignore errors = no\n";
    print RSN "ignore nonreadable = yes\n";
    print RSN "transfer logging = no\n";
    print RSN "log format = %t: host %h \(%a\) %o %f \(%l bytes\). Total %b bytes.\n";
    print RSN "timeout = 600\n";
    print RSN "refuse options = checksum dry-run\n";
    print RSN "dont compress = *.gz *.tgz *.zip *.z *.rpm *.deb *.iso *.bz2 *.tbz\n";
    print RSN "\n";
}

if ( "%CloudBox{cloudbox.network.webdav_server}%" eq "yes" ) {
    system("echo \"\# iDC WebDAV services\" > /etc/rc.webdav");
    #system("echo \"killall apache2\" >> /etc/rc.webdav");
    #system("echo \"sleep 3\" >> /etc/rc.webdav");
    system("echo \"/bin/systemctl daemon-reload\" >> /etc/rc.webdav");
    system("echo \"echo DataBox\" >> /etc/rc.webdav");
    system("echo \"/bin/systemctl restart apache2\" >> /etc/rc.webdav");
    system("echo \"/bin/systemctl status apache2\" >> /etc/rc.webdav");
    system("chmod 755 /etc/rc.webdav");

    #open(DAV,">> /etc/apache2/sites-available/000-default.conf");
    #print DAV "\tWSGIDaemonProcess cloudgate user=local group=apache threads=5\n";
    #print DAV "\tWSGIScriptAlias /wsgi/ /etc/itd/wsgi/cloudgate.wsgi/\n";
    #print DAV "\t<Directory \"/etc/itd/wsgi/\">\n";
    #print DAV "\t\tWSGIProcessGroup cloudgate\n";
    #print DAV "\t\tWSGIApplicationGroup \%{GLOBAL}\n";
    #print DAV "\t\tWSGIScriptReloading On\n";
    #print DAV "\t\tRequire host localhost\n";
    #print DAV "\t\tRequire ip 172.17\n";
    #print DAV "\t\tRequire all granted\n";
    #print DAV "\t</Directory>\n";

    #print DAV "\n";
    #print DAV "\tDocumentRoot /var/www\n";
    #print DAV "\t<Directory \"/var/www/\">\n";
    #print DAV "\t\tOptions Indexes FollowSymLinks MultiViews\n";
    #print DAV "\t\tAllowOverride None\n";
    #print DAV "\t\tRequire host localhost\n";
    #print DAV "\t\tRequire ip 172.17\n";
    #print DAV "\t\tRequire all granted\n";
    #print DAV "\t</Directory>\n";

    if ( "%CloudBox{cloudbox.network.public_webdav_server}%" eq "yes" ) {
	foreach my $entry (@pubentries) {
	    my $cloud = $entry -> get_value("cn");
	    my $comment = $entry -> get_value("iDCloudName");

	    #open(DAV,">> /etc/apache2/sites-available/000-default.conf");
	    open(DAV,">> /etc/apache2/conf-available/data.conf");
	    #print DAV "\tScriptAlias /$cloud/bin/ /etc/itd/bin/\n";
	    print DAV "\tAlias /$cloud/ /export/public/$cloud/\n";

	    print DAV "\t<Directory \"/export/public/$cloud/\">\n";
	    print DAV "\t\tAllowOverride None\n";
	    #print DAV "\t\tRequire host localhost\n";
	    #print DAV "\t\tRequire ip 172.17\n";
	    print DAV "\t\tRequire all granted\n";
	    print DAV "\t\tDAV On\n";
	    print DAV "\t</Directory>\n";

	    print DAV "\t<Location \"/$cloud/\">\n";
	    print DAV "\t\tSatisfy any\n";
	    print DAV "\t\tAuthType Basic\n";
	    print DAV "\t\tAuthName \"$comment (readonly)\"\n";
	    print DAV "\t\tAuthBasicProvider ldap\n";
	    print DAV "\t\tAuthLDAPUrl \"ldap://localhost/ou=Users,$baseID?uid\"\n";
	    print DAV "\t\tAuthLDAPBindDN \"cn=proxyuser,$baseID\"\n";
	    print DAV "\t\tAuthLDAPBindPassword \"openlab\"\n";
	    print DAV "\t\tRequire valid-user\n";
	    print DAV "\t</Location>\n";
	    print DAV "\n";
	}
    }

    if ( "%CloudBox{cloudbox.network.private_webdav_server}%" eq "yes" ) {
	foreach my $entry (@prientries) {
	    my $cloud = $entry -> get_value("cn");
	    my $gid = $entry -> get_value("gidNumber");
	    my $dav_port = $gid - $boxID*10000;
	    my $pridav_port = $dav_port*2 + 1001;
	    print DAV "\tProxyPass /$cloud/ http://localhost:$pridav_port/$cloud/\n";
	    print DAV "\tProxyPassReverse /$cloud/ http://localhost:$pridav_port/$cloud/\n";
	    system("echo \"/bin/echo $cloud\" >> /etc/rc.webdav");
	    #system("echo \"/bin/ls /export/private/$cloud\" >> /etc/rc.webdav");
	    system("echo \"/bin/systemctl restart apache2-$pridav_port\" >> /etc/rc.webdav");
	    system("echo \"/bin/systemctl status apache2-$pridav_port\" >> /etc/rc.webdav");
	}
    }

    if ( "%CloudBox{cloudbox.network.personal_webdav_server}%" eq "yes" ) {
	foreach my $entry (@usrentries) {
	    my $userDN = $entry -> dn;
	    my ($dnstr,$basestr) = split(",",$userDN);
	    my ($dn,$cloud) = split("=",$dnstr);

	    my $check_st;
	    my @ous = $entry -> get_value("ou");
	    foreach my $st ( @ous ) {
		if ( $st =~ /active|sensor/ ) {
		    $check_st = "active";
		    last;
		}
	    }

	    if ( $check_st eq "active" ) {
		my $uid = $entry -> get_value("uidNumber");
		my $dav_port = $uid - $boxID*10000;
		my $perdav_port = $dav_port*2 + 1000;
		print DAV "\tProxyPass /$cloud/ http://localhost:$perdav_port/$cloud/\n";
		print DAV "\tProxyPassReverse /$cloud/ http://localhost:$perdav_port/$cloud/\n";
		system("echo \"echo $uid\" >> /etc/rc.webdav");
		#system("echo \"/bin/ls /export/users/$cloud\" >> /etc/rc.webdav");
		system("echo \"/bin/systemctl restart apache2-$perdav_port\" >> /etc/rc.webdav");
		system("echo \"/bin/systemctl status apache2-$perdav_port\" >> /etc/rc.webdav");
	    }
	}
    }

    #print DAV "</VirtualHost>\n";
    close(DAV);

    system("[ ! -L /etc/apache2/log ] && /bin/ln -s /var/log/apache2 /etc/apache2/log");
}

close(RSN);
close(PWD);

$mesg = $ldap -> unbind;

system("chmod 0600 /etc/itd/template/rsyncd.secrets");
exit 0;
