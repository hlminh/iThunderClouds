#!/usr/bin/env python
# -*- coding: utf-8 -*-
__author__="dtson"
__date__ ="$25-10-2012 14:30:24$"
import sys
try:
	import os
	import datetime
	from daemon import Daemon
	import logging
	import time
	#from multiprocessing import Process, Queue
	import Queue
	import threading
	import pyinotify
	from pyinotify import WatchManager, Notifier, ThreadedNotifier, EventsCodes, ProcessEvent
	import subprocess
	import xml
	import shutil
	from xml.dom import minidom
	from modules.idc_functions import get_xml_value, trim_path, get_device_ip
except Exception, e:
	print "error: %s" %e
	sys.exit(1)
TIMEOUT = 10
WATERLEVEL = "200,220,240,260,280,300,320,340,360,380,400"
PROG_PATH = sys.path[0]
MODULE_PATH = PROG_PATH + "/modules"
TEMP_PATH = "/tmp/watchingtmp"

try:
	BOXID = "netbox"
	f = open('/conf/.CloudBox/cloudbox.conf', 'r')
	confdata = f.read()
	f.close()
	confdata = confdata.split("\n")
	for data in confdata:
		if data.find("boxID") != -1:
			id = data.split(":")[1].strip()
			BOXID = id.split("'")[1]
			break
except:
	BOXID="netbox"

def is_not_empty_file(filename):
	try:
		f = open(filename, 'r')
		s = f.read()
		f.close()
		s = s.replace("\n", "")
		s = s.strip()
		if s == "":
			return False
		else:
			return True
	except Exception, e:
		return False
	

def get_rsync_smb_conf(conftype="rsync"):
	#get configuration from /conf/.CloudBox/cloudbox.conf
	try:
		f = open('/conf/.CloudBox/cloudbox.conf', 'r')
		confdata = f.read()
		f.close()
	except:
		confdata = ""
	if conftype == "rsync":
		#confdic = {"public_clouds_rsync": "", "public_clouds_rsync_ID": ""}
		#paralist = ["public_clouds_rsync", "public_clouds_rsync_ID"]
		confdic = {"public_clouds_rsync": ""}
		paralist = ["public_clouds_rsync"]
	else:
		confdic = {"public_clouds_smb": ""}
		paralist = ["public_clouds_smb"]

	if confdata != "":
		for x in confdata.split("\n"):
			for para in paralist:
				if x.find(para+" :") != -1 or x.find(para+":") != -1:
					try:
						confdic[para] = x.split(":")[1]
						confdic[para] = confdic[para].strip().split("'")[1]
					except:
						logging.debug("Cannot get configuration for %s" %para)
					break
		for key, value in confdic.items():
			if value == "":
				logging.debug("Cannot apply rsync/smb watching because of lacking of configuration")
				return None
		if conftype == "rsync":
			RET = confdic["public_clouds_rsync"]
		else:
			#RET = confdic["public_clouds_smb_IP"], confdic["public_clouds_smb_user"], confdic["public_clouds_smb_passwd"], confdic["public_clouds_domain"], confdic["public_clouds_smb_share"], confdic["public_clouds_smb_folder"]
			RET = confdic["public_clouds_smb"]
		return RET

class WorkflowThread(threading.Thread):
	def __init__(self, queue, admin, passwd, services, cloud, cloud_path):
		threading.Thread.__init__(self)
		self.queue = queue
		self.services = services
		self.cloud_path = cloud_path
		self.cloud = cloud
		self.admin = admin
		self.passwd = passwd
		self.rsync_default_ID = None
		self.smb_default_ID = None
		#get extra parameter from configuration file
		if "RSYNC" in self.services:
			ret = get_rsync_smb_conf()
			if ret != None:
			    rsync_cloud_src = ret
			    rsync_cloud_src = rsync_cloud_src.split(",")
			    for x in rsync_cloud_src:
				try:
					if x.split(":")[0].strip() == self.cloud:
						self.rsync_default_ID = x.split(":")[1].strip()
				except:
					#logging.debug('%s: Cannot get rsync parameter' %self.cloud)
					pass
			
		if "SMB" in self.services:
			ret = get_rsync_smb_conf("smb")
			if ret != None:
			    smb_cloud_src, smb_cloud_dest = ret
			    smb_cloud_src = smb_cloud_src.split(",")
			    smb_cloud_dest = smb_cloud_dest.split(",")
			    if len(smb_cloud_dest) != len(smb_cloud_src):
				logging.debug('%s: Cannot get smb parameter' %self.cloud)
			    else:
				try:
					self.smb_default_ID = smb_cloud_dest[smb_cloud_src.index(self.cloud)]
				except:
					pass
		
		self.last_water_level = 0
		self.level_list = []
		for level in  WATERLEVEL.split(","):
			try:
				self.level_list.append(float(level))
			except:
				pass
	def run(self):
		while 1:
			if not self.queue.empty():
				while 1:
					qsize = self.queue.qsize()
					#wait 10 secs
					#time.sleep(10)
					if self.queue.qsize() == qsize:
						break
				tmpfilename1 = "filewrite_%s" %self.cloud
				tmpfilename2 = "filedelete_%s" %self.cloud
				tmpfilename3 = "dirdelete_%s" %self.cloud
				tmpfilename4 = "dircreate_%s" %self.cloud
				fwrite = open(os.path.join(TEMP_PATH,tmpfilename1),'w')
				fdel = open(os.path.join(TEMP_PATH,tmpfilename2),'w')
				ddel = open(os.path.join(TEMP_PATH,tmpfilename3),'w')
				dcreate = open(os.path.join(TEMP_PATH,tmpfilename4),'w')
				while not self.queue.empty():
					data = self.queue.get()
					action, path, name = data
					#fullpath = os.path.join(path, name)
					if action == "FILEWRITE" or action == "FILEMOVETO":
						fwrite.write(path+"$:$"+name+"\n")
					elif action == "DELETE":
						fdel.write(path+"$:$"+name+"\n")
					elif action == "DIRDELETE":
						ddel.write(path+"$:$"+name+"\n")
					elif action == "DIRCREATE":
						
						dcreate.write(path+"$:$"+name+"\n")
				fwrite.close()
				fdel.close()
				ddel.close()
				dcreate.close()
				fwrite = is_not_empty_file(os.path.join(TEMP_PATH,tmpfilename1))
				fdel = is_not_empty_file(os.path.join(TEMP_PATH,tmpfilename2))
				ddel = is_not_empty_file(os.path.join(TEMP_PATH,tmpfilename3))
				dcreate = is_not_empty_file(os.path.join(TEMP_PATH,tmpfilename4))
				if "INDEX" in self.services:
					idccontent_folder = os.path.join(self.cloud_path,'.content')
					idcindex_folder = os.path.join(self.cloud_path,'.index')
					if os.path.isdir(idccontent_folder) and os.path.isdir(idcindex_folder):
						if fwrite:
							#command = 'su %s -c "%s/idc_indexing.py indexfilelist %s %s %s %s"' %(self.admin, MODULE_PATH, idccontent_folder, idcindex_folder, os.path.join(TEMP_PATH,tmpfilename1), "None")
							#p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
							#ret =  p.communicate()
							#ret, err = ret
							#if err != '':
							#	logging.debug('%s: Cannot index: %s' %(self.cloud,err))
							#index
							command = 'su %s -c "%s/idc_indexing.py indexfilelist %s %s %s %s"' %(self.admin, MODULE_PATH, idccontent_folder, idcindex_folder, os.path.join(TEMP_PATH,tmpfilename1), "None")
							#logging.debug("%s: %s"%(self.cloud, command))
							p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
							ret =  p.communicate()
							ret, err = ret
							if err != '':
								logging.debug('%s: Cannot index: %s' %(self.cloud,err))
							else:
								logging.debug('%s: add to index success' %self.cloud)
						if fdel:
							command = 'su %s -c "%s/idc_indexing.py delindexfilelist %s %s %s %s"' %(self.admin, MODULE_PATH, idccontent_folder, idcindex_folder, os.path.join(TEMP_PATH,tmpfilename2), "None")
							logging.debug("%s: %s"%(self.cloud, command))
							p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
							ret =  p.communicate()
							ret, err = ret
							if err != '':
								logging.debug('%s: Cannot del index: %s' %(self.cloud,err))

				#check action
				if "INDEXFILE" in self.services:
					if fwrite:
						command = 'su %s -c "%s/idc_indexfile.py updateindexfromlist %s %s"' %(self.admin, MODULE_PATH, os.path.join(TEMP_PATH,tmpfilename1), self.cloud_path)
						logging.debug("%s: %s"%(self.cloud, command))
						p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
						ret =  p.communicate()
						ret, err = ret
						if err != '':
							logging.debug('%s: Cannot index: %s' %(self.cloud,err))
					if fdel:
						command = 'su %s -c "%s/idc_indexfile.py cleanindexfromlist %s %s"' %(self.admin, MODULE_PATH, os.path.join(TEMP_PATH,tmpfilename2), self.cloud_path)
						logging.debug("%s: %s"%(self.cloud, command))
						p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
						ret =  p.communicate()
						ret, err = ret
						if err != '':
							logging.debug('%s: Cannot del index: %s' %(self.cloud,err))
					if ddel:
						command = 'su %s -c "%s/idc_indexfile.py cleanindexfromlist %s %s"' %(self.admin, MODULE_PATH, os.path.join(TEMP_PATH,tmpfilename3), self.cloud_path)
						logging.debug("%s: %s"%(self.cloud, command))
						p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
						ret =  p.communicate()
						ret, err = ret
						if err != '':
							logging.debug('%s: Cannot del index: %s' %(self.cloud,err))
		
				if "EMAILALERT" in self.services:
					if fwrite:
						#usage: idc_emailalert <filelist> <cloudpath> <cloud> <boxid>"
						command = '%s/idc_emailalert.py %s %s %s %s' %(MODULE_PATH, os.path.join(TEMP_PATH,tmpfilename1), self.cloud_path, self.cloud, BOXID)
						logging.debug("%s: %s"%(self.cloud, command))
						p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
						ret =  p.communicate()
						ret, err = ret
						if err != '':
							logging.debug('%s: Cannot sendemail: %s' %(self.cloud,err))
						logging.debug('%s: %s' %(self.cloud,ret))
				if "SENSORALARM" in self.services:
					pass
					
				if "RSYNC" in self.services:
					if fwrite:
						#"usage: %s <filelist> <cloudpath> <cloud> <boxid>" % sys.argv[0]
						command = 'su %s -c "%s/idc_workflow.py %s %s %s %s"' %(self.admin, MODULE_PATH, os.path.join(TEMP_PATH,tmpfilename1), self.cloud_path, self.cloud, BOXID)
						logging.debug("%s: %s"%(self.cloud, command))
						p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
						ret =  p.communicate()
						ret, err = ret
						if err != '':
							logging.debug('%s: Cannot do workflow: %s' %(self.cloud,err))
						logging.debug('%s: %s' %(self.cloud,ret))	
						
					if fwrite and self.rsync_default_ID  != None:
						#read to file
						#f_tmp = open(os.path.join(TEMP_PATH,tmpfilename1), 'r')
						#lines = f_tmp.readlines()
						#f_tmp.close()
						#for line in lines:
						#	try:
						#		path, name = line.split("$:$")[0], line.split("$:$")[1]
						#		name = name.strip()
						#		path = path.strip()
						#	except:
						#		continue
							#full_path = os.path.join(path, name)
							full_path = self.cloud_path + "/"
							#rsync_IP, rsync_user, rsync_passwd = self.rsync_para
							rsync_user = self.admin
							rsync_passwd = self.passwd
							rsync_add = get_device_ip(self.rsync_default_ID)
							try:
								rsync_IP = rsync_add.split(":")[0]
								rsync_port = rsync_add.split(":")[1]
							except:
								rsync_IP = rsync_add
								rsync_port = "873"
							if rsync_IP != None:
								share = self.cloud + "/"
								share = share.replace("-:-","/")
								try:
									command = 'su %s -c "export RSYNC_PASSWORD=%s;/usr/bin/rsync -au %s %s@%s::%s --port=%s"' %(rsync_user, rsync_passwd, full_path, rsync_user, rsync_IP, share,rsync_port)
								except:
									logging.debug('%s: Cannot execute rsync' %self.cloud)
							else:
								logging.debug('%s: Error: Cannot find IP of server for rsync' %self.cloud)
							logging.debug('%s: %s'%(self.cloud, command))
							if command != "":
								p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
								ret =  p.communicate()
								ret, err = ret
								if err != '':
									logging.debug('%s: Cannot execute %s: %s' %(self.cloud,command,err))
				if "SMB" in self.services:
					if fwrite and self.smb_para != None:
						#read to file
						lines = ""
						try:
							f_tmp = open(os.path.join(TEMP_PATH,tmpfilename1), 'r')
							lines = f_tmp.readlines()
							f_tmp.close()
						except:
							lines = ""
						for line in lines:
							try:
								path, name = line.split("$:$")[0], line.split("$:$")[1]
								name = name.strip()
								path = path.strip()
							except:
								continue
							self.samba_upload(self.smb_para, path, name)
				
				if "SENSORINDEX" in self.services:
					if fwrite:
						command = 'su %s -c "%s/idc_sensorindexing.py indexfilelist %s %s"' %(self.admin, MODULE_PATH, self.cloud_path, os.path.join(TEMP_PATH,tmpfilename1))
						logging.debug("%s: %s"%(self.cloud, command))
						p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
						ret =  p.communicate()
						ret, err = ret
						if err != '':
							logging.debug('%s: Cannot index: %s' %(self.cloud,err))
			else:
				time.sleep(0.3)

	def samba_upload(self, para, path, name):
		smb_IP, smb_user, smb_passwd, domain, share, folder_mapping = para
		full_path = os.path.join(path, name)
		#first, convert to pdf
		value = ""
		if os.path.splitext(name)[1] != '.xml':
			return
		try:
			doc = minidom.parse(full_path)
			doc_type = get_xml_value(doc, 'type')
			value = get_xml_value(doc, 'identifier.code')
			if value == None or value == "":
				value = str(int(time.time()))
			else:
				value = value.replace("/", "-")
				value = value.replace("\\", "-")
				value = value.replace(" ", "-")
				value = value.replace(">", "-")
				value = value.replace("<", "-")
				value = value.replace("?", "-")
				value = value.replace(",", "-")
				value = value.replace("&", "-")
				value = value.replace("*", "-")
				value = value.replace(")", "-")
				value = value.replace("(", "-")
				value = value.replace("^", "-")
				value = value.replace("%", "-")
				value = value.replace("$", "-")
				value = value.replace("#", "-")
				value = value.replace("@", "-")
				value = value.replace("!", "-")
				value = value.replace("~", "-")
				value = value.replace("`", "-")
				value = value.replace(".", "-")
				value = value.replace(":", "-")
				value = value.replace('"', "-")
				value = value.replace("'", "-")
		except Exception, e:
			logging.debug("Cannot get info for document: %s" %e)
			return
		logging.debug(value)
		tiff_file=os.path.splitext(full_path)[0] + ".tif"
		pdf_file= "/tmp/" + value + ".pdf"
		if os.path.isfile(tiff_file):
			command = "%s/pdf_export.py %s %s" %(MODULE_PATH, tiff_file, pdf_file)
			p = subprocess.Popen(command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			ret =  p.communicate()
			ret, err = ret
			if err != '':
				logging.debug('%s: Cannot convert to pdf' %self.cloud)
		if os.path.isfile(pdf_file):
			remoteshare = {}
			for mapping in folder_mapping.split(","):
				try:
					remoteshare[mapping.split("@")[0].strip()] = mapping.split("@")[1].strip()
				except:
					continue
			#1140004@Congvanden, 1140005@Congvandi
			#remoteshare={'1140004':'Congvanden', '1140005':'Congvandi'}
			#smb_IP, smb_user, smb_passwd, domain, share = para
			now = datetime.datetime.now()
			if now.day < 10:
				day = '0%d' %now.day
			else:
				day = '%d' %now.day
			if now.month < 10:
				month = '0%d' %now.month
			else:
				month = '%d' %now.month
			year = '%d' %now.year
			p_folder = None
			try:
				p_folder = remoteshare[doc_type]
			except:
				p_folder = None
			if p_folder == None:
				logging.debug('\tCannot send to samba server: No folder for type %s' %doc_type)
				return
			command = 'smbclient //%s/%s -U=%s' %(smb_IP, share, smb_user)+ '%' + '%s -c "mkdir %s; cd %s; mkdir %s; cd %s; mkdir %s; cd %s; mkdir %s; cd %s; lcd /tmp/; put %s"' %(smb_passwd, p_folder, p_folder, year, year, month, month, day, day, value+".pdf")
			logging.debug(command)
			p = subprocess.Popen(command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			ret =  p.communicate()
			ret, err = ret
			if err == '':
				logging.debug('\tCannot send to samba server: %s' %err)
			else:
				logging.debug('\t%s has sent to samba server' %pdf_file)
				os.remove(pdf_file)

class MyProcessing(ProcessEvent):
	def __init__(self, queue):
		self.queue = queue
		self.event_list = []
		

	def process_IN_CREATE(self, event):
		self.event_list.append(1)
		#logging.debug('%s: CREATE' % os.path.join(event.path, event.name))
		full_path = os.path.join(event.path, event.name)
		try:
			tmp_path = event.path.split('/')
			if not ".content" in tmp_path:
				for tmp in tmp_path:
					if len(tmp) > 0:
						if tmp[0] in ['.','~','$']:
							return
			if event.name[0] in ['.','~','$']:
				return
		except Exception, e:
			print e
		if os.path.isdir(full_path):
			data = "DIRCREATE", event.path,event.name
			self.queue.put(data)
		try:
			#get permission
			st = os.stat(full_path)
			stmode = oct(st.st_mode)
			stmode = stmode.strip()
			stmode = stmode[len(stmode)-3:len(stmode)]
			if stmode != "044":
				if os.path.isdir(full_path):
					for (path, dirs, files) in os.walk(full_path):
						for xfile in files:
							os.chmod(os.path.join(path,xfile), 0644)
						for xdir in dirs:
							os.chmod(os.path.join(path,xdir), 1744)
				if os.path.isfile(full_path):
					os.chmod(full_path, 0644)
		except Exception, e:
			logging.debug('Cannot change mode: '+str(e))

	def process_IN_CLOSE_WRITE(self, event):
		logging.debug('Close_write: %s' %os.path.join(event.path, event.name))
		full_path = os.path.join(event.path, event.name) 
		try:
			tmp_path = event.path.split('/')
			if not ".content" in tmp_path:
				for tmp in tmp_path:
					if len(tmp) > 0:
						if tmp[0] in ['.','~','$']:
							return
			if event.name[0] in ['.','~','$']:
				return
		except Exception, e:
			print e
		if os.path.isfile(full_path):
			logging.debug('%s: %s' %("FILEWRITE", full_path))
			data = "FILEWRITE", event.path,event.name
			self.queue.put(data)

	def process_IN_CLOSE_NOWRITE(self, event):
		pass

	def process_IN_DELETE(self,event):
		full_path = os.path.join(event.path, event.name)
		logging.debug('%s: %s' %("FILEDELETE", full_path))
		try:
			tmp_path = event.path.split('/')
			if not ".content" in tmp_path:
				for tmp in tmp_path:
					if len(tmp) > 0:
						if tmp[0] in ['.','~','$']:
							return
			if event.name[0] in ['.','~','$']:
				return
		except Exception, e:
			print e
		logging.debug('%s: %s' %("FILEDELETE", full_path))
		data = "DELETE", event.path,event.name
		self.queue.put(data)

	def process_IN_MODIFY(self, event):
		pass
		#self.event_list.append(2)
		#logging.debug('%s: MODIFY' % os.path.join(event.path, event.name))

	def process_IN_MOVED_TO(self, event):
		#logging.debug('%s: %s' %(action,os.path.join(event.path, event.name)))
		full_path = os.path.join(event.path, event.name) 
		try:
			tmp_path = event.path.split('/')
			if not ".content" in tmp_path:
				for tmp in tmp_path:
					if len(tmp) > 0:
						if tmp[0] in ['.','~','$']:
							return
			if event.name[0] in ['.','~','$']:
				return
		except Exception, e:
			print e
		if os.path.isfile(full_path):
			logging.debug('%s: %s' %("FILEMOVETO", full_path))
			data = "FILEMOVETO", event.path,event.name
			self.queue.put(data)

	def process_IN_MOVED_FROM(self, event):
		#logging.debug('MOVED_FROM: %s' %os.path.join(event.path, event.name))
		pass
	def process_default(self, event):
		"""
		Ultimately, this method is called for all others kind of events.
		This method can be used when similar processing can be applied
		to various events.
		"""
		pass

class iDCE_watching_daemon(Daemon):
	def __init__ (self, pidfile):
		#create temp folder
		if not os.path.isdir(TEMP_PATH):
			os.mkdir(TEMP_PATH)
		self.services = []
		Daemon.__init__ (self, pidfile)
	def set_configuration(self, log_path, cloud, cloud_path, admin, passwd, services):
		logfile = os.path.join(log_path, 'idc_%s.log' %cloud)
		self.default_index_log = log_path
		try:
			logging.basicConfig(filename=logfile, level=logging.DEBUG, format="%(asctime)s [%(levelname)s] %(message)s")
		except Exception, e:
			print 'cannot create debug log file for deamon'
			sys.exit(1)
		self.cloud = cloud
		self.cloud_path = cloud_path
		self.admin = admin
		self.passwd = passwd
		
		try:
			for service_str in services.upper().split(","):
				self.services.append(service_str.strip())
		except:
			logging.debug('%s: Cannot start service: wrong configuration' %self.cloud)

	def run(self):
		logging.debug('%s: Starting service...' %self.cloud)
		try:
		    os.listdir(self.cloud_path)
		except Exception, e:
		    logging.debug('%s: Cannot start service: "%s" cannot list' %(self.cloud, self.cloud_path))
		    sys.exit(1)
		if not os.path.isdir(self.cloud_path):
			logging.debug('%s: Cannot start service: "%s" does not exist' %(self.cloud, self.cloud_path))
			sys.exit(1)
		
		indexing_log_location = "None"
		delete_index = []
		for i in range(len(self.services)):
			service = self.services[i]
			if service == "INDEX":
				logging.debug('%s: re-indexing everything...' %self.cloud)
				content_folder = os.path.join(self.cloud_path, ".content")
				try:
					if not os.path.isdir(content_folder):
						logging.debug('%s: Did not find .content folder, the cloud may not be Reposistory' %self.cloud)
						delete_index.append(i)
					if os.path.isdir(content_folder):
					    rootcloudpath = os.path.dirname(content_folder)
					    index_folder = os.path.join(rootcloudpath, ".index")
					    if not os.path.isdir(index_folder):
						try:
						    os.mkdir(index_folder)
						except Exception, e:
						    pass
					    if os.path.isdir(index_folder):
					    	#usage: %s indexfolder <root> <index_folder> <indexed_folder> <index_log> 0
					    	command = 'su %s -c "%s/idc_indexing.py indexfolder %s %s %s %s 0"' %(self.admin,MODULE_PATH, content_folder, index_folder, content_folder , indexing_log_location)
					    	p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
					    	ret =  p.communicate()
					    	ret, err = ret
					    	ret = ret.replace("\n","")
					    	err = err.replace("\n","")
					    	if err == '':
							logging.debug('%s: Indexed %s documents: ' %(self.cloud,ret))
					    	else:
							logging.debug('%s: Cannot index: %s' %(self.cloud,err))
					    else:
						logging.debug('%s: Cannot specify .index folder' %self.cloud)
						
				except Exception,e:
					logging.debug('%s Cannot re-indexing: %s' %(self.cloud,e))

			if service == "INDEXFILE":
				logging.debug('%s: re-indexing every files...' %self.cloud)
				try:
					#print "usage: %s indexfolder <Folder>" % sys.argv[0]
					command = 'su %s -c "%s/idc_indexfile.py indexfolder %s"' %(self.admin,MODULE_PATH,self.cloud_path)
					p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
					ret =  p.communicate()
					ret, err = ret
					ret = ret.replace("\n","")
					err = err.replace("\n","")
					if err == '':
						logging.debug('%s: Finished: %s' %(self.cloud,ret))
					else:
					    logging.debug('%s: Cannot index: %s' %(self.cloud,err))
				except Exception,e:
					logging.debug('%s Cannot re-indexing: %s' %(self.cloud,e))

			if service == "SENSORINDEX":
				logging.debug('%s: re-indexing every files...' %self.cloud)
				try:
					#usage: %s indexfolder <root> <index_folder> <indexed_folder> <index_log> 0
					command = 'su %s -c "%s/idc_sensorindexing.py indexfolder %s"' %(self.admin,MODULE_PATH, self.cloud_path)
					p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
					ret =  p.communicate()
					ret, err = ret
					#ret = ret.replace("\n","")
					#err = err.replace("\n","")
					if err == '':
					    logging.debug('%s: Following sensor folders were indexed:\n %s' %(self.cloud,ret))
					else:
					    logging.debug('%s: Cannot index: %s' %(self.cloud,err))
				except Exception,e:
					logging.debug('%s Cannot re-indexing: %s' %(self.cloud,e))
		for i in delete_index:
			del self.services[i]
		#add watch 
		i = 0
		queue = Queue.Queue()
		wm = WatchManager()
		#self.notifier = Notifier(wm, MyProcessing(None, None))
		self.notifier = Notifier(wm)
		mask = pyinotify.IN_MODIFY | pyinotify.IN_CREATE | pyinotify.IN_DELETE | pyinotify.IN_CLOSE_WRITE | pyinotify.IN_CLOSE_NOWRITE | pyinotify.IN_MOVED_FROM | pyinotify.IN_MOVED_TO
		try:
			service_str = ""
			for sername in self.services:
				if service_str != "":
					service_str = service_str + ", " +  sername
				else:
					service_str = sername
			para = self.cloud_path, self.services
			#mask = pyinotify.ALL_EVENTS
			#wm.add_watch('/home/1162023/temp', rec=True, mask, proc_fun=MyProcessing(self.q))
			wm.add_watch(self.cloud_path, mask, rec=True, proc_fun=MyProcessing(queue), auto_add=True)
			logging.debug('%s: watched for %s' %(self.cloud, service_str))
		except Exception,e:
				logging.debug('%s: Cannot initialize inotify: %s' %(self.cloud,e))
				logging.debug('%s: Start failed...' %self.cloud)
				sys.exit(1)
		logging.debug('successfully initialize daemon')
		logging.debug('Service started...')
		workflow = WorkflowThread(queue,self.admin,self.passwd, self.services, self.cloud, self.cloud_path)
		workflow.start()
		while 1:
			self.notifier.process_events()
			if self.notifier.check_events():
				self.notifier.read_events()

if __name__ == "__main__":
	
	if len(sys.argv) >= 2:
		
		if 'start' == sys.argv[1]:
			if len(sys.argv) == 7:
				daemon = iDCE_watching_daemon('/run/watching_%s.pid' %sys.argv[2])
				daemon.set_configuration("/tmp", sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5],sys.argv[6])
				daemon.start()
				#daemon.run()
			else:
				print "Not enought parameter"
				print "usage: %s start <cloudname> <cloudpath> <admin> <pass> <services>" % sys.argv[0]
				sys.exit(2)
		elif 'stop' == sys.argv[1]:
			if len(sys.argv) == 3:
				daemon = iDCE_watching_daemon('/run/watching_%s.pid' %sys.argv[2])
				daemon.stop()
			else:
				print "Not enought parameter"
				print "usage: %s stop <cloudname>" % sys.argv[0]
				sys.exit(2)
		else:
			print "Unknown command"
			sys.exit(2)
		sys.exit(0)
	else:
		print "usage: %s start <cloudname> <cloudpath> <admin> <services>" % sys.argv[0]
		print "usage: %s stop <cloudname>" % sys.argv[0]
		sys.exit(2)
	

