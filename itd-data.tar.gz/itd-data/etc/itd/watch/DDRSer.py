#!/usr/bin/env python
# -*- coding: utf-8 -*-
__author__="dtson"
__date__ ="$14-05-2013 09:30:00$"
import sys
try:
	from daemon2 import Daemon
	import time
	import datetime
	import logging
	import os
	import pwd
	import socket
	import subprocess
except Exception, e:
	print "error: %s" %e
	sys.exit(1)


class DDRSer_daemon(Daemon):
	def Get_Info (self, CloudID=None, CloudPath=""):
		try:
			ID = int(CloudID)
		except:
			#return False
			pass
		#get owner of Cloud
		if os.path.isdir(CloudPath):
			try:
				s = os.stat(CloudPath)
				uid = s.st_uid
				gid = s.st_gid
				admin2 = pwd.getpwuid(uid).pw_name
				return admin2
			except Exception, e:
				logging.debug('%s: Cannot get owner ID for %s' %(self.CloudID, self.CloudPath))
				return False

		return False
	
	def __init__ (self, pidfile, CloudID, CloudPath=""):
		logfile = os.path.join("/tmp/.DDRSer", 'idc_%s.log' %CloudID)
		try:
			logging.basicConfig(filename=logfile, level=logging.DEBUG, format="%(asctime)s [%(levelname)s] %(message)s")
		except Exception, e:
			print 'cannot create debug log file for deamon'
			sys.exit(1)
		self.CloudID = CloudID
		self.CloudPath = CloudPath
		Daemon.__init__ (self, pidfile)
	def run(self):
		logging.debug('%s: Starting service...' %self.CloudID)
		if not os.path.isdir(self.CloudPath):
			logging.debug('%s: the %s does not exist...' %(self.CloudID, self.CloudPath))
			sys.exit(1)
		#get infor for Camera
		ret = self.Get_Info (self.CloudID,self.CloudPath)
		if ret == False:
			logging.debug('%s: Cannot get configuration...' %self.CloudID)
			sys.exit(1)
		self.ownerID=ret
		#create a unix domain socket
		server_address = '/tmp/.DDRSer/uds_socket_%s' %self.CloudID
		# Make sure the socket does not already exist
		try:
			os.unlink(server_address)
		except OSError:
			pass
			#logging.debug('%s: Cannot create unix domain socket...' %self.CloudID)
			#sys.exit(1)
		try:
			socket.setdefaulttimeout(2)
			sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
			# Bind the socket to the port
			sock.bind(server_address)
			# Listen for incoming connections
			sock.listen(20)
			
		except Exception, e:
			print e
			logging.debug('%s: Cannot create unix domain socket...' %self.CloudID)
			sys.exit(1)
		while True:
			# Wait for a connection
			try:
				connection, client_address = sock.accept()
			except Exception, e:
				logging.debug('%s: Cannot accept connection...' %self.CloudID)
				continue
			logging.debug('%s: Accepted connection from %s...' %(self.CloudID,str(client_address)))
			# Receive the data in small chunks and retransmit it
			try:
				recv_data = ""
				while True:
				    try:
					data = connection.recv(16)
				    except socket.timeout:
					print "timeout"
					break
				    if len(data) < 16:
					recv_data=recv_data+data
					break
				    else:
					recv_data=recv_data+data
				#do action with recv_data
				if recv_data != "":
					para_list=recv_data.split("$:$")
					if len(para_list) == 3:
						cmd=para_list[0]
						if cmd == "cpfile":
							src=para_list[1]
							dst=para_list[2]
							command = 'su %s -c "/bin/cp %s %s"' %(self.ownerID,src,dst)
							p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
							ret =  p.communicate()
							ret, err = ret
							ret = ret.strip()
							err = err.strip()
							if err == '':
								logging.debug('%s: [%s] execute success...' %(self.CloudID,command))
								connection.sendall("OK")
							else:
								logging.debug('%s: Cannot execute [%s] [%s]...' %(self.CloudID,command,err))
								connection.sendall("NOTOK")
						elif cmd == "cpdir":
							src=para_list[1]
							dst=para_list[2]
							# check dst is existed
							if not os.path.isdir(dst):
								#create folder
								command = 'su -l %s -c "mkdir -p %s"' %(self.ownerID,dst)
								p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
								ret =  p.communicate()
								ret, err = ret
								err = err.strip()
								if err == '':
									logging.debug('%s: [%s] execute success...' %(self.CloudID,command))
									#connection.sendall("OK")
								else:
									logging.debug('%s: Cannot execute [%s] [%s]...' %(self.CloudID,command,err))
									#connection.sendall("NOTOK")
							if os.path.isdir(dst):
								command = 'su %s -c "/bin/cp -r %s %s"' %(self.ownerID,src,dst)
								p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
								ret =  p.communicate()
								ret, err = ret
								ret = ret.strip()
								err = err.strip()
								if err == '':
									logging.debug('%s: [%s] execute success...' %(self.CloudID,command))
									connection.sendall("OK")
								else:
									logging.debug('%s: Cannot execute [%s] [%s]...' %(self.CloudID,command,err))
									connection.sendall("NOTOK")
						elif cmd == "delfile":
							src=para_list[1]
							#dst=para_list[2]
							command = 'su %s -c "/bin/rm -f %s"' %(self.ownerID,src)
							p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
							ret =  p.communicate()
							ret, err = ret
							ret = ret.strip()
							err = err.strip()
							if err == '':
								logging.debug('%s: [%s] execute success...' %(self.CloudID,command))
								connection.sendall("OK")
							else:
								logging.debug('%s: Cannot execute [%s] [%s]...' %(self.CloudID,command,err))
								connection.sendall("NOTOK")
						elif cmd == "deldir":
							src=para_list[1]
							#dst=para_list[2]
							command = 'su %s -c "/bin/rm -rf %s"' %(self.ownerID,src)
							p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
							ret =  p.communicate()
							ret, err = ret
							ret = ret.strip()
							err = err.strip()
							if err == '':
								logging.debug('%s: [%s] execute success...' %(self.CloudID,command))
								connection.sendall("OK")
							else:
								logging.debug('%s: Cannot execute [%s] [%s]...' %(self.CloudID,command,err))
								connection.sendall("NOTOK")
						else:
							logging.debug('%s: The request is not match [%s]...' %(self.CloudID,cmd))		
							connection.sendall("NOTOK")
					else:
						logging.debug('%s: The request is invalid [%s]...' %(self.CloudID,cmd))		
						connection.sendall("NOTOK")
				connection.close()
			except Exception, e:
				print e
				logging.debug('%s: error: %s' %(self.CloudID,e))
				connection.close()

	
if __name__ == "__main__":
	if len(sys.argv) == 3 or len(sys.argv) == 4:
		USER_DIR =  "/tmp/.DDRSer"
		piddir = USER_DIR
		if not os.path.isdir(piddir):
			try:
				os.mkdir(piddir)
			except:
				print "Cannot create configuration folder: %s" %piddir
				sys.exit(1)
		if not os.path.isdir(piddir):
			print "Cannot found configuration folder: %s" %piddir
			sys.exit(1)
		pidfile = os.path.join(piddir,'DDRSer_%s.pid' %sys.argv[2])
		if 'start' == sys.argv[1]:
			if len(sys.argv) == 4:
				daemon = DDRSer_daemon(pidfile, sys.argv[2], sys.argv[3])
				daemon.start(sys.argv[2])
				#daemon.run()
			else:
				print "Not enough arguments"
				sys.exit(2)
	
		elif 'stop' == sys.argv[1]:
				daemon = DDRSer_daemon(pidfile, sys.argv[2])
				daemon.stop(sys.argv[2])
		else:
			print "Unknown command"
			sys.exit(2)
		sys.exit(0)
	else:
		print "usage: %s start <CloudID> <CloudPath>" % sys.argv[0]
		print "usage: %s stop <CloudID>" % sys.argv[0]
		sys.exit(2)
	

