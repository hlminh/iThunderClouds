#!/usr/bin/env python
# -*- coding: utf-8 -*-
__author__="dtson"
__date__ ="$04-10-2012$"

import sys
try:
	import os
	import lucene
	import pwd
	import grp
	import subprocess
	import datetime
	import time
except Exception, e:
	print "Index_process: Error in importing lib: [%s]" %e
	sys.exit(0)

MODULE_NAME = 'idc_indexing'
LuceneMaxFieldLength = 1048576
#INDEX_LOG = sys.path[0]

def index_process(filelist, root_folder, index_log):
	index_folder = os.path.join(root_folder,".index")
	#if not os.path.isdir(index_folder):
	#	return
	logfile = os.path.join(index_log,'index_log.log')
	write_to_log(logfile, 'index process started')
	write_to_log(logfile, "updating %s" %root_folder)
	UpdateIndex(filelist, index_folder, index_log)
	#update md5
	filename_abs_path = ""
	for ff in os.listdir(index_folder):
		if ff.endswith('.fdt'):
			filename_abs_path = os.path.join(index_folder, ff)
			break
	filename_abs_path.replace(' ','\\ ')
	try:
		popen = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
		file_md5_str =  popen.communicate()
		file_md5_str, b = file_md5_str
		file_md5_str = file_md5_str.split (' ')[0]
		if len(file_md5_str) != 32:
			file_md5_str = ''
	except Exception, e:
		write_to_log(logfile, "%s" %e)
		file_md5_str = ''
	try:
		file(os.path.join(index_folder, '.md5'),'w+').write("%s\n" % file_md5_str)
	except Exception, e:
		pass

def write_to_log(logfile, msg):
	file_path = logfile
	try:
		f = open(file_path,"a")
	except IOError,e:
		raise Exception('Can not open file %s: %s' %(file_path,e))
		return
	text =  datetime.datetime.now().strftime("%Y/%m/%d	%H:%M:%S") + '	%s\n' %msg 
	try:
		f.write(text)
	except IOError,e:
		raise Exception('Can not write file %s: %s' %(file_path,e))
		f.close()
		return
	f.close()
	return   

def add_cloudtype_to_index(writer, cloudtype):
		doc = lucene.Document()
		#no store and un ANALYZED
		doc.add(lucene.Field("CloudType", cloudtype,lucene.Field.Store.YES,lucene.Field.Index.NO_ANALYZED))
		writer.addDocument(doc)


def add_to_index(writer, path, name, parentNodeID, NodeType):
		#get file stat
		#print parentNodeID
		fullpath = os.path.join(path,name)
		s = os.stat(fullpath)
		doc = lucene.Document()
		#no store and un ANALYZED
		doc.add(lucene.Field("NodeID", str(s.st_ino),lucene.Field.Store.YES,lucene.Field.Index.NO_ANALYZED))
		doc.add(lucene.Field("ParentNodeID", str(parentNodeID), lucene.Field.Store.NO, lucene.Field.Index.ANALYZED))
		doc.add(lucene.Field("NodeType", NodeType, lucene.Field.Store.YES, lucene.Field.Index.NO_ANALYZED))
		#store and unANALYZED
		doc.add(lucene.Field("Path", path, lucene.Field.Store.YES, lucene.Field.Index.NO_ANALYZED))
		permission = oct(s.st_mode)
		doc.add(lucene.Field("Permission", str(permission), lucene.Field.Store.YES, lucene.Field.Index.NO_ANALYZED))
		owner = pwd.getpwuid(s.st_uid)[0]
		doc.add(lucene.Field("Owner", owner, lucene.Field.Store.YES, lucene.Field.Index.NO_ANALYZED))
		group = grp.getgrgid(s.st_gid)[0]
		doc.add(lucene.Field("Group", group, lucene.Field.Store.YES, lucene.Field.Index.NO_ANALYZED))
		#store and ANALYZED
		doc.add(lucene.Field("Name", name, lucene.Field.Store.YES, lucene.Field.Index.ANALYZED))
		doc.add(lucene.Field("ModifiedTime", str(s.st_mtime), lucene.Field.Store.YES, lucene.Field.Index.ANALYZED))
		doc.add(lucene.Field("CreatedTime", str(s.st_ctime), lucene.Field.Store.YES, lucene.Field.Index.ANALYZED))
		doc.add(lucene.Field("AccessedTime", str(s.st_atime), lucene.Field.Store.YES, lucene.Field.Index.ANALYZED))
		if NodeType == "F":
			doc.add(lucene.Field("Size", str(s.st_size), lucene.Field.Store.YES, lucene.Field.Index.ANALYZED))														  
		#doc.add(lucene.Field("md5", md5_str, lucene.Field.Store.YES,lucene.Field.Index.ANALYZED))
		writer.addDocument(doc)
		return s.st_ino

def Index_folder(folder, index_log):
	logfile = os.path.join(index_log,'index_log.log')
	write_to_log(logfile, "indexing %s" %folder)
	index_folder = os.path.join(folder, ".index")
	update = False
	i = 0

	if not os.path.exists(index_folder):
		try:
			os.mkdir(index_folder)
		except Exception, e:
			#print e
			write_to_log(logfile, "cannot create index folder")
			return -1
	store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, True)
	writer_parameter = True
	try:
		writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
	except lucene.JavaError, e:
		if os.path.isfile(os.path.join(index_folder, "write.lock")):
			try:
				os.remove(os.path.join(index_folder, "write.lock"))
				writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
			except Exception, e:
				write_to_log(logfile, "%s" %e)
				return -1
		else:
				return -1
	writer.setMaxFieldLength(LuceneMaxFieldLength)
	add_cloudtype_to_index(writer, "FileSystem")
	totalfiles = doIndex(writer, folder, 0)
	write_to_log(logfile, "%d have been add to index" %totalfiles)
	print totalfiles
	write_to_log(logfile, "optimizing index store")
	writer.optimize()
	writer.close()
	write_to_log(logfile, "Cleaning index store")
	#clean_index(index_folder, folder,logfile)
	filename_abs_path = ""
	for ff in os.listdir(index_folder):
		if ff.endswith('.fdt'):
			filename_abs_path = os.path.join(index_folder, ff)
			break
	filename_abs_path.replace(' ','\\ ')
	try:
		popen = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
		file_md5_str =  popen.communicate()
		file_md5_str, b = file_md5_str
		file_md5_str = file_md5_str.split (' ')[0]
		if len(file_md5_str) != 32:
			file_md5_str = ''
	except Exception, e:
		write_to_log(logfile, "%s" %e)
		file_md5_str = ''
	try:
		file(os.path.join(index_folder, '.md5'),'w+').write("%s\n" % file_md5_str)
	except Exception, e:
		pass

def doIndex(writer, folder, parentNodeID):
	total = 0
	for node in os.listdir(folder):
		fullpath = os.path.join(folder, node)
		if node[0] == ".":
			continue
		if node == '.index':
			continue
		if os.path.isfile(fullpath):
			#print "adding %s" %fullpath
			nodeid = add_to_index(writer, folder, node, parentNodeID, "F")
			total = total + 1
		if os.path.isdir(fullpath):
			#print "adding %s" %fullpath
			nodeid = add_to_index(writer, folder, node, parentNodeID, "D")
			total = total + 1
			r = doIndex(writer, fullpath, nodeid)
			total = total + r
	return total


def UpdateIndex(filelist, index_folder, index_log):
	logfile = os.path.join(index_log,'index_log.log')
	lines = []
	try:
		f_tmp = open(filelist, 'r')
		lines = f_tmp.readlines()
		f_tmp.close()
	except:
		lines = []
	if lines == []:
		return False
	try:
		update = False
		if not os.path.exists(index_folder):
			try:
				os.mkdir(index_folder)
			except OSError, e:
				write_to_log(logfile, "cannot create index folder at %s: [%s]" %(index_folder,e))
				return e
			store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, True)
			writer_parameter = True
		elif os.path.isfile(os.path.join(index_folder, "segments.gen")):
			store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, False)
			writer_parameter = False
			update = True
		else:
			store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, True)
			#writer = lucene.IndexWriter(store, analyzer, True)
			writer_parameter = True
		writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
		writer.setMaxFieldLength(LuceneMaxFieldLength)
		if not update:
			try:
				add_cloudtype_to_index(writer, "FileSystem")
			except:
				pass
		for line in lines:
			try:
				path, name = line.split("$:$")[0], line.split("$:$")[1]
				name = name.strip()
				path = path.strip()
			except:
				continue
			fullpath = os.path.join(path,name)
			if os.path.isdir(fullpath) or os.path.isfile(fullpath):
				#get file nodeID
				s = os.stat(fullpath)
				nodeID = s.st_ino
				if update:
					num, nodename = getHitCount(store, 'NodeID',str(nodeID))
					if num > 0:
						if writer != None:
							writer.close()
						t = lucene.Term('NodeID', str(nodeID))
						reader = lucene.IndexReader.open(store, False)
						reader.deleteDocuments(t)
						reader.close()
						writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
						writer.setMaxFieldLength(LuceneMaxFieldLength)
					else:
						num, nodeid, nodename = getHitCount2(store, 'Path',path)
						if num > 0:
							if nodename.strip() == name.strip():
								if writer != None:
									writer.close()
								t = lucene.Term('NodeID', nodeid)
								reader = lucene.IndexReader.open(store, False)
								reader.deleteDocuments(t)
								reader.close()
								writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
								writer.setMaxFieldLength(LuceneMaxFieldLength)
								
				s = os.stat(path)
				parentNodeID = s.st_ino
				try:
					if os.path.isdir(fullpath):
						nodetype = "D"
					else:
						nodetype = "F"
					add_to_index(writer, path, name, parentNodeID, nodetype)
				except Exception, e:
					write_to_log(logfile, 'can not index file %s. Error: %s' %(name,e))
					continue
		write_to_log(logfile,'optimizing index') 
		writer.optimize()
		writer.close()
	except Exception, e:
		write_to_log(logfile, "cannot index: %s" %e)
		return False


def getHitCount2(dir, fieldName, searchString):
	searcher = lucene.IndexSearcher(dir)
	t = lucene.Term(fieldName, searchString)
	query = lucene.TermQuery(t)
	hits = searcher.search(query,50).scoreDocs
	hitCount = len(hits)
	md5_str = ''
	nodeid = ''
	name = ''
	if hitCount == 1:
		for hit in hits:
			doc = searcher.doc(hit.doc)
			name = doc.get("Name")
			nodeid = doc.get("NodeID")
	searcher.close()
	return hitCount, nodeid, name


def getHitCount(dir, fieldName, searchString):
	searcher = lucene.IndexSearcher(dir)
	t = lucene.Term(fieldName, searchString)
	query = lucene.TermQuery(t)
	hits = searcher.search(query, 50).scoreDocs
	hitCount = len(hits)
	md5_str = ''
	nodeid = ''
	name = ''
	if hitCount == 1:
		for hit in hits:
			doc = searcher.doc(hit.doc)
			name = doc.get("Name")
	searcher.close()
	return hitCount, name
	
def clean_index(filelist, root_folder, INDEX_LOG):
	logfile = os.path.join(INDEX_LOG,'index_log.log')
	index_folder = os.path.join(root_folder, ".index")
	lines = []
	try:
		f_tmp = open(filelist, 'r')
		lines = f_tmp.readlines()
		f_tmp.close()
	except:
		lines = []
	if lines == []:
		return False
	try:
		directory = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, False)
		for line in lines:
			try:
				path, name = line.split("$:$")[0], line.split("$:$")[1]
				name = name.strip()
				path = path.strip()
			except:
				continue
			fullpath = os.path.join(path, name)
			num, nodeid, nodename = getHitCount2(directory, 'Path',path)
			if num > 0:
				if nodename.strip() == name.strip():
					if not os.path.isfile(fullpath) and not os.path.isdir(fullpath):
						t = lucene.Term('NodeID', nodeid)
						reader = lucene.IndexReader.open(directory, False)
						reader.deleteDocuments(t)
						reader.close()
						write_to_log(logfile, 'delete document at %s' %abs_path)
	except Exception, e:
		write_to_log(logfile, "%s" %e)
	return

if __name__ == "__main__":
	lucene.initVM(lucene.CLASSPATH)
	#index_process(path, file_name, index_folder, root, index_log)
	USER = os.getenv('USER')
	indexlog = '/tmp/' + USER
	if not os.path.isdir(indexlog):
		os.mkdir(indexlog)
	#print indexlog
	#Index_folder(HOME + "/workspace", indexlog)
	#sys.exit(0)
	if len(sys.argv) > 1:
		try:
			if sys.argv[1].upper() == 'UPDATEINDEXFROMLIST':
				index_process(sys.argv[2], sys.argv[3], indexlog)
			elif sys.argv[1].upper() == 'INDEXFOLDER':
				Index_folder(sys.argv[2], indexlog)
			elif sys.argv[1].upper() == 'CLEANINDEXFROMLIST':
				clean_index(sys.argv[2], sys.argv[3], indexlog)
		except Exception, e:
			#print e
			print "unknow option"
	else:
		print "usage: %s updateindexfromlist <filelist> <rootfolder>" % sys.argv[0]
		print "usage: %s indexfolder <Folder>" % sys.argv[0]
		print "usage: %s cleanindexfromlist <filelist> <rootfolder>" % sys.argv[0]
		sys.exit(0)

