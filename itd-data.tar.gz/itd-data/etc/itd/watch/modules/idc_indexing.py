#!/usr/bin/env python
# -*- coding: utf-8 -*-
__author__="dtson"
__date__ ="$04-10-2011$"
import sys
try:
	import os
	from xml.dom import minidom
	import lucene
	from idc_functions import get_all_collection_id
	#from Module.configuration import *
	import subprocess
	import datetime
	import time
except Exception, e:
	print "Index_process: Error in importing lib: [%s]" %e
	sys.exit(1)

PROG_PATH = sys.path[0]
MODULE_NAME = 'idc_indexing'
LuceneMaxFieldLength = 1048576
#INDEX_LOG = sys.path[0]

def write_to_log(logfile, msg):
	file_path = logfile
	try:
		f = open(file_path,"a")
	except IOError,e:
		raise Exception('Can not open file %s: %s' %(file_path,e))
		return

	text =  datetime.datetime.now().strftime("%Y/%m/%d	%H:%M:%S") + '	%s\n' %msg 
	try:
		f.write(text)
	except IOError,e:
		raise Exception('Can not write file %s: %s' %(file_path,e))
		f.close()
		return
	f.close()
	return   

def is_xml_file_valid(filename):
	name = filename.split('.')[0]
	for i in range(len(name)):
		if name[i].upper() not in ['0', '1', '2','3', '4', '5', '6','7','8', '9', '-', '_','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','T','R','S','T','U','V','W','X','Y','Z']:
			return False
	return True

def is_valid_store_folder(path):
	name = path.strip()
	for i in range(len(name)):
		if name[i] not in ['0', '1', '2','3', '4', '5', '6','7','8', '9']:
			return False
	return True

def add_cloudtype_to_index(writer, cloudtype):
		doc = lucene.Document()
		#no store and un ANALYZED
		doc.add(lucene.Field("CloudType", cloudtype,lucene.Field.Store.YES,lucene.Field.Index.NOT_ANALYZED))
		writer.addDocument(doc)


def indexDocs(collections,lucene_dir, ID, root, path,filename, writer, logfile,md5_str = '' ):
	try:
		#----- read all field in metadata file (xml file)
		if path == None or path == '':
			path ='/'
		abs_path = os.path.join(path, filename)
		abs_path = root + abs_path
		indexed_field, collection_list = read_metadata_field(abs_path)
		#----- end read metadata field ------
		doc = lucene.Document()
		doc.add(lucene.Field("ID", ID,
							 lucene.Field.Store.YES,
							 lucene.Field.Index.NOT_ANALYZED ))
		doc.add(lucene.Field("name", filename,
							 lucene.Field.Store.YES,
							 lucene.Field.Index.NOT_ANALYZED ))
		doc.add(lucene.Field("path", path,
							 lucene.Field.Store.YES,
							 lucene.Field.Index.NOT_ANALYZED ))
		doc.add(lucene.Field("md5", md5_str,
							 lucene.Field.Store.YES,
							 lucene.Field.Index.NOT_ANALYZED ))
		for c in collection_list:
		    collid = c.strip()
		    doc.add(lucene.Field("DC:RELATION.COLLECTION",collid,
			 lucene.Field.Store.NO,
				 lucene.Field.Index.NOT_ANALYZED ))
				
		metadata = ''
		for x in indexed_field:
			name, value = x
			metadata = metadata + name + '$:$' +value + '\n'
			name = name.upper()
			tmp = name.split(':')
			if "SOURCE.COLLECTION" in tmp:
				tmpvaluelist = value.split(" ")
				notincoll = True
				for xcoll in tmpvaluelist:
				    coll = xcoll.strip()
				    doc.add(lucene.Field(name, coll,
								 lucene.Field.Store.NO,
								 lucene.Field.Index.NOT_ANALYZED ))
				    if coll in collections:
					notincoll = False
				if notincoll:
				    collid = ""
				    for xcollid in collections:
					if xcollid.find(".000")!= -1:
					    collid = xcollid
				    if collid:
					doc.add(lucene.Field(name, collid,
								 lucene.Field.Store.NO,
								 lucene.Field.Index.NOT_ANALYZED ))

			else:
				doc.add(lucene.Field(name, value,
								 lucene.Field.Store.NO,
								 lucene.Field.Index.ANALYZED))
		fulltext = ''

		doc.add(lucene.Field('metadata', metadata,
						lucene.Field.Store.YES,
						lucene.Field.Index.ANALYZED))

		f = None
		fulltext_path = os.path.splitext(abs_path)[0] + '.txt'
		if os.path.isfile(fulltext_path):
			try:
				f = open(fulltext_path, 'r')
				fulltext = f.read()
				f.close()
			except Exception, e:
				print MODULE_NAME + ' :%s' %e
				if f:
					f.close()

		doc.add(lucene.Field('fulltext', fulltext,
						lucene.Field.Store.NO,
						lucene.Field.Index.ANALYZED))

		writer.addDocument(doc)
	except:
		pass

def getHitCount(dir, fieldName, searchString):
	searcher = lucene.IndexSearcher(dir)
	t = lucene.Term(fieldName, searchString)
	query = lucene.TermQuery(t)
	hits = searcher.search(query,50).scoreDocs
	hitCount = len(hits)

	md5_str = ''
	if hitCount == 1:
		for hit in hits:
			#doc = lucene.Hit.cast_(hit).getDocument()
			doc = searcher.doc(hit.doc)
			md5_str = doc.get("md5")
	searcher.close()
	return hitCount, md5_str


def read_metadata_field(filename):
	def viewNode(v):

		out = None
		dem = v.childNodes.length
		if dem>1:
			j = 1
			while j < dem:
				w = v.childNodes[j]
				if v.tagName == 'DC:Relation.Collection':
					cid=v.getAttribute('id')
					if cid not in collection_list:
					    collection_list.append(cid)
				out = viewNode(w)
				j = j + 2
		if dem==1:
			temp = v.tagName.upper()
			out = v.firstChild.data
			field_list.append((temp, out))

	field_list = []
	collection_list = []
	doc = minidom.parse(filename)
	count = doc.firstChild.childNodes.length
	u = doc.firstChild
	if count>1:
		i = 1
		while i < count:
				v = u.childNodes[i]
				out = viewNode(v)
				i = i + 2
	else:
	  temp = u.tagName.upper()
	  field_list.append((temp, u.firstChild.data))
	return field_list, collection_list

def trim_path(root, path):
	r = root.strip()
	p = path.strip()
	i  = p.find(r)
	if i!= -1:
		return p[i+len(r):]
	else:
		return None

def indexfilelist(collection_folder, index_folder, filelist,index_log):
	collections = get_all_collection_id(os.path.join(collection_folder,"collection.xml"))
	if collections == -1:
	    collections = []
	logfile = os.path.join(index_log,'index_log.log')
	update = False
	if not os.path.exists(index_folder):
		try:
			os.mkdir(index_folder)
		except OSError, e:
			write_to_log(logfile, "cannot create index folder at %s: [%s]" %(index_folder,e))
			return -1
		store = lucene.SimpleFSDirectory(lucene.File(index_folder))	#lucene.FSDirectory.getDirectory(index_folder, True)
		writer_parameter = True
		#writer = lucene.IndexWriter(store, analyzer, True)
	elif os.path.isfile(os.path.join(index_folder, "segments.gen")):
		store = lucene.SimpleFSDirectory(lucene.File(index_folder))	#lucene.FSDirectory.getDirectory(index_folder, False)
		writer_parameter = False
		update = True
	else:
		store = lucene.SimpleFSDirectory(lucene.File(index_folder))	#lucene.FSDirectory.getDirectory(index_folder, True)
		writer_parameter = True
	try:
		writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)	#lucene.IndexWriter(store, lucene.StandardAnalyzer(), writer_parameter)
	except lucene.JavaError, e:
		if os.path.isfile(os.path.join(index_folder, "write.lock")):
			try:
				os.remove(os.path.join(index_folder, "write.lock"))
				writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)	#lucene.IndexWriter(store, lucene.StandardAnalyzer(), writer_parameter)
			except Exception, e:
				write_to_log(logfile, "%s" %e)
				return -1
		else:
			return -1
	writer.setMaxFieldLength(LuceneMaxFieldLength)
	lines = []
	try:
		f_tmp = open(filelist, 'r')
		lines = f_tmp.readlines()
		f_tmp.close()
	except:
		lines = []
	if not update:
		try:
			add_cloudtype_to_index(writer, "Reposistory")
		except:
			pass
	for line in lines:
		try:
			path, name = line.split("$:$")[0], line.split("$:$")[1]
			name = name.strip()
			path = path.strip()
		except Exception, e:
			continue
		tmp = os.path.basename(path)
		if not is_valid_store_folder(tmp):
			continue
		if not name.endswith('.xml'):
			continue
		ID = name.split('.')[0]
		if is_xml_file_valid(name):
			filename_abs_path = os.path.join(path, name)
#				 check permission
			try:
				f = open(filename_abs_path, 'r')
			except IOError, e:
				continue
			f.close()
#				get md5 of file
			filename_abs_path = filename_abs_path.strip()
			filename_abs_path.replace(' ','\\ ')
			#Put into the queue
			try:
				write_to_log(logfile, "put document into the queue %s" %filename_abs_path)
				#write_to_log(logfile, PROG_PATH + '/importQ')
				p = subprocess.Popen ([PROG_PATH + '/importQ', filename_abs_path], shell = False, stdout=subprocess.PIPE)
				ret_str =  p.communicate()
				write_to_log(logfile, "importQ return: %s" %str(ret_str))
			except Exception, e:
				write_to_log(logfile, "[queue import] %s" %e)
			#Try add to index store
			try:
				p = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
				file_md5_str =  p.communicate()
				file_md5_str, b = file_md5_str
				file_md5_str = file_md5_str.split (' ')[0]
				if len(file_md5_str) != 32:
					file_md5_str = ''
			except Exception, e:
				write_to_log(logfile, "%s" %e)
				file_md5_str = ''
			trimpath = trim_path(collection_folder,path)
			if trimpath != None:
				if update:
					num, md5_str = getHitCount(store, 'ID',ID)
					if num > 1:
						t = lucene.Term('ID', ID)
						if writer != None:
							writer.close()
						reader = lucene.IndexReader.open(store, False)
						reader.deleteDocuments(t)
						reader.close()
						writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED) #lucene.IndexWriter(store, lucene.StandardAnalyzer(), writer_parameter)
						writer.setMaxFieldLength(LuceneMaxFieldLength)
					elif num == 1:
						if md5_str != file_md5_str:
							t = lucene.Term('ID', ID)
							if writer != None:
								writer.close()
							reader = lucene.IndexReader.open(store, False)
							reader.deleteDocuments(t)
							reader.close()
							writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED) #lucene.IndexWriter(store, lucene.StandardAnalyzer(), writer_parameter)
							writer.setMaxFieldLength(LuceneMaxFieldLength)
						else:
							continue
				try:
					write_to_log(logfile, "indexing %s" %name)
					indexDocs(collections,store, ID, collection_folder, trimpath,name, writer, logfile, file_md5_str)
				except Exception, e:
					write_to_log(logfile, "%s" %e)
					continue

	write_to_log(logfile, "optimizing index store")										
	writer.optimize()
	writer.close()
	filename_abs_path = ""
	for ff in os.listdir(index_folder):
		if ff.endswith('.fdt'):
			filename_abs_path = os.path.join(index_folder, ff)
			break
	filename_abs_path.replace(' ','\\ ')
	try:
		popen = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
		file_md5_str =  popen.communicate()
		file_md5_str, b = file_md5_str
		file_md5_str = file_md5_str.split (' ')[0]
		if len(file_md5_str) != 32:
			file_md5_str = ''
	except Exception, e:
		write_to_log(logfile, "%s" %e)
		file_md5_str = ''
	try:
		file(os.path.join(index_folder, '.md5'),'w+').write("%s\n" % file_md5_str)
	except Exception, e:
		pass
	#print "%d/%d" %(j,i)

def Index_folder(collection_folder, index_folder, indexed_folder,index_log, init_num = 0):
	logfile = os.path.join(index_log,'index_log.log')
	write_to_log(logfile, "indexing %s" %indexed_folder)
	_root = indexed_folder
	i = 0
	j = 0
	collections = get_all_collection_id(os.path.join(collection_folder,"collection.xml"))
	if collections == -1:
	    collections = []

	if not os.path.exists(index_folder):
		try:
			os.mkdir(index_folder)
		except Exception, e:
			write_to_log(logfile, "cannot create index folder")
			return -1
	store = lucene.SimpleFSDirectory(lucene.File(index_folder))	
	#store = lucene.FSDirectory.getDirectory(index_folder, True)
	writer_parameter = True
	try:
		#analyzer = StandardAnalyzer(Version.LUCENE_30)
		writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
		#writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(), writer_parameter)
	except lucene.JavaError, e:
		if os.path.isfile(os.path.join(index_folder, "write.lock")):
			try:
				os.remove(os.path.join(index_folder, "write.lock"))
				writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
			except Exception, e:
				write_to_log(logfile, "%s" %e)
				return -1
		else:
			return -1
	writer.setMaxFieldLength(LuceneMaxFieldLength)
	writer.setUseCompoundFile(True)
	add_cloudtype_to_index(writer, "Reposistory")
	for root, dirnames, filenames in os.walk(_root):
		tmp = os.path.basename(root)
		if not is_valid_store_folder(tmp):
			continue
		for filename in filenames:
			if not filename.endswith('.xml'):
				continue
			ID = filename.split('.')[0]
			if is_xml_file_valid(filename):
				i = i + 1
				filename_abs_path = os.path.join(root, filename)
#				check permission
				try:
					f = open(filename_abs_path, 'r')
				except IOError, e:
					continue
				f.close()
#				get md5 of file
				filename_abs_path = filename_abs_path.strip()
				filename_abs_path.replace(' ','\\ ')
				try:
					p = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
					file_md5_str =  p.communicate()
					file_md5_str, b = file_md5_str
					file_md5_str = file_md5_str.split (' ')[0]
					if len(file_md5_str) != 32:
						file_md5_str = ''
				except Exception, e:
					write_to_log(logfile, "%s" %e)
					file_md5_str = ''
				path = trim_path(collection_folder,root) 
				if path != None:
					try:
						indexDocs(collections,store, ID, collection_folder, path,filename, writer, logfile, file_md5_str )
						j = j + 1
					except Exception, e:
						write_to_log(logfile, "%s" %e)
						continue

	write_to_log(logfile, "optimizing index store")
	writer.optimize()
	writer.close()
	filename_abs_path = ""
	for ff in os.listdir(index_folder):
		if ff.endswith('.fdt'):
			filename_abs_path = os.path.join(index_folder, ff)
			break
	filename_abs_path.replace(' ','\\ ')
	try:
		popen = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
		file_md5_str =  popen.communicate()
		file_md5_str, b = file_md5_str
		file_md5_str = file_md5_str.split (' ')[0]
		if len(file_md5_str) != 32:
			file_md5_str = ''
	except Exception, e:
		write_to_log(logfile, "%s" %e)
		file_md5_str = ''
	try:
		file(os.path.join(index_folder, '.md5'),'w+').write("%s\n" % file_md5_str)
	except Exception, e:
		pass
	print "%d/%d" %(j,i)


def delindexfilelist(root, index_folder, filelist, index_log):
	logfile = os.path.join(index_log,'index_log.log')
	try:
		directory = lucene.SimpleFSDirectory(lucene.File(index_folder))	#lucene.FSDirectory.getDirectory(index_folder, False)
		lines = []
		try:
			f_tmp = open(filelist, 'r')
			lines = f_tmp.readlines()
			f_tmp.close()
		except:
			lines = []
		for line in lines:
			try:
				path, name = line.split("$:$")[0], line.split("$:$")[1]
				name = name.strip()
				path = path.strip()

			except:
				continue
			tmp = os.path.basename(path)
			if not is_valid_store_folder(tmp):
				continue
			if not name.endswith('.xml'):
				continue
			ID = name.split('.')[0]
			if is_xml_file_valid(name):
				num, md5_str = getHitCount(directory, 'ID',ID)
				if num >= 1:
					t = lucene.Term('ID', ID)
					reader = lucene.IndexReader.open(directory)
					reader.deleteDocuments(t)
					reader.close()
					write_to_log(logfile, "delete file %s" %name)
		filename_abs_path = ""
		for ff in os.listdir(index_folder):
			if ff.endswith('.fdt'):
				filename_abs_path = os.path.join(index_folder, ff)
				break
		filename_abs_path.replace(' ','\\ ')
		try:
			popen = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
			file_md5_str =  popen.communicate()
			file_md5_str, b = file_md5_str
			file_md5_str = file_md5_str.split (' ')[0]
			if len(file_md5_str) != 32:
				file_md5_str = ''
		except Exception, e:
			write_to_log(logfile, "%s" %e)
			file_md5_str = ''
		try:
			file(os.path.join(index_folder, '.md5'),'w+').write("%s\n" % file_md5_str)
		except Exception, e:
			pass
	except Exception, e:
		write_to_log(logfile, "%s" %e)
	return

if __name__ == "__main__":
	if len(sys.argv) >= 6:
		lucene.initVM(lucene.CLASSPATH)
		#index_process(path, file_name, index_folder, root, index_log)
		USER = os.getenv('USER')
		indexlog = '/tmp/' + USER
		if not os.path.isdir(indexlog):
			os.mkdir(indexlog)
		#print indexlog
		if sys.argv[1].upper() == 'INDEXFILELIST':
			indexfilelist(sys.argv[2], sys.argv[3], sys.argv[4], indexlog)
		elif sys.argv[1].upper() == 'INDEXFOLDER':
			if len(sys.argv) >= 7:
				Index_folder(sys.argv[2], sys.argv[3], sys.argv[4], indexlog, sys.argv[6])
			else:
				print "unknow option"
				sys.exit(2)
			#collection_folder, index_folder, indexed_folder,index_log
		elif sys.argv[1].upper() == 'DELINDEXFILELIST':
			delindexfilelist(sys.argv[2], sys.argv[3],sys.argv[4], indexlog)
		else:
			print "unknow option"
			sys.exit(2)
	else:
		print "usage: %s indexfolder <root> <index_folder> <indexed_folder> <index_log> 0" % sys.argv[0]
		print "usage: %s indexfilelist <root> <index_folder> <filelist> <index_log>" % sys.argv[0]
		print "usage: %s delindexfilelist <root> <index_folder> <filelist> <index_log>" % sys.argv[0]
		sys.exit(1)
