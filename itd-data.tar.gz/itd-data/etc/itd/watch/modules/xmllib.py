#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os.path
import os
import sys, string
from xml.dom import minidom, Node
from xml.dom.minidom import Document

data_list = {'DC:Date.Received':'20120118', 'DC:Date.Issued':'20120808'}
template_path = './template/template1.xml'
data_path = './132685809932.xml'

def remove_attr(node): # remove attributes of a node
    if (node.nodeType == node.ELEMENT_NODE):
	if (node.hasAttributes):
	    attr_list = node.attributes
	    for attr_name in attr_list.keys():
		if (attr_name != 'label') and (attr_name != 'desc') and (attr_name!= 'xmlns:DC') and (attr_name!= 'required') and (attr_name!= 'xmlns:Repo'):
		    node.removeAttribute(attr_name)
	#print node.attributes.keys()
	if node.hasChildNodes():
	    for nodes in node.childNodes:
		remove_attr(nodes)

def remove_node_by_name(node, name):
    if node.hasChildNodes:
	array = node.childNodes
	for nodes in array:
	    if nodes.nodeName == name:
		    node.removeChild(nodes)
	    else: 
		remove_node_by_name(nodes, name)


def remove_empty_text_node(node):
    if node.hasChildNodes:
	array = node.childNodes
	for nodes in array:
	    if nodes.nodeType == nodes.TEXT_NODE:
		string = nodes.nodeValue
		string = string.strip()
		if (string==""):
		    node.removeChild(nodes)
		    #print "lalaal"
	    else: 
		remove_empty_text_node(nodes)
	       
	    
	    
def get_data_from_old_xml(node,tupl):
    if (node.nodeType == node.ELEMENT_NODE):
	value = node.firstChild.nodeValue
	#print len(value)  , value
	if (value!=" ") and (value[0] != "\n") :
	    tupl[node.nodeName] = value
	if (node.hasChildNodes):
	    for nodes in node.childNodes:
		get_data_from_old_xml(nodes,tupl)
    return tupl

def create_xml(xmlDoc,tup, Ptagname):
    for key in tup.keys():
	node = xmlDoc.getElementsByTagName(key)
	if Ptagname:
		for xnode in node:
			if xnode.parentNode != None:
				#print xnode.parentNode.nodeName
				if xnode.parentNode.nodeName == Ptagname:
					xnode.firstChild.nodeValue = tup[key]
		#print len(node), node[0].firstChild, tup[key]
	else:
		node[0].firstChild.nodeValue = tup[key]
	#print  node[0].firstChild, node[0].firstChild.nodeValue
    return xmlDoc
    
def print_xml(root):
    print root.nodeName, root.nodeValue
    if root.hasChildNodes:
	for node in root.childNodes:
	    print_xml(node)

def save_xmllib(temp_path, d_path, data,Ptagname=""):
    xmlDoc = minidom.parse(temp_path)
    template_root = xmlDoc.documentElement
    remove_attr(template_root)
    remove_node_by_name(template_root, "DC:SendTo")
#    old_xmlDoc = minidom.parse(d_path)
#    data_root = old_xmlDoc.documentElement
    tup = {}
    #get_data_from_old_xml(data_root,tup)
    for key  in data.keys():
	tup[key] = data[key]
    create_xml(xmlDoc,tup, Ptagname)
    #print_xml(xmlDoc.documentElement)
    remove_empty_text_node(xmlDoc.documentElement)
    #print "------------------------"
    #print_xml(xmlDoc.documentElement)
    f = open(d_path,'w')
    lines = xmlDoc.toprettyxml(encoding = 'utf-8')
    for line in lines.split("\n"):
	if line.strip() == "":
		continue
	f.write(line+"\n")
    f.close()
    return 0

if __name__ == '__main__':
	main(template_path, data_path, data_list)

