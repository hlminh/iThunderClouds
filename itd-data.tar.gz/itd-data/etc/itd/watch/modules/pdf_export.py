#!/usr/bin/env python
# -*- coding: utf-8 -*-
try:
    import subprocess
    import sys
    import os
    import time
    import Image
    import ImageSequence
except Exception, e:
    print "pdf_export: Error in importing lib: [%s]" %e
    sys.exit(0)

MODULE_NAME = 'pdf_export'

def path_proceed(_s):
    s = _s.strip()
    return s.replace(' ','\\ ')

def export_to_pdf(_tiff_file, _location):
    #set page setup,
    #set print settings
    #_________________________
    #set page number
    #
    if _tiff_file.endswith('tiff') or _tiff_file.endswith('tif'):
        im = None
        try:
            im = Image.open(_tiff_file)
        except Exception, e:
            print MODULE_NAME + ': %s' %e
	
	if os.path.isdir(_location):
		print "pdf file must be specified"
		return False

        save_location = path_proceed(_location)
        
	if im != None:
          tiff_file = path_proceed(_tiff_file)

          im = ImageSequence.Iterator(im)
#          total_page_number = 0
#          for x in im:
#                #do nothing, just calculate the page number
#                total_page_number = total_page_number + 1
#          print total_page_number
            # show the print dialog
          
          if os.path.isfile(sys.path[0] + '/tiff2pdf'):
            command = self.path_proceed(sys.path[0]) + '/tiff2pdf '
          else:
            command = 'tiff2pdf '
          #print im[0].mode
          if im[0].mode == 'RGB':
            command = command + '-n -z -f -r d -o %s %s' %(save_location, tiff_file)
          else:
            command = command + '-n -z -f -r d -o %s %s' %(save_location, tiff_file)
#          print command
          im = None
          try:
            retcode = subprocess.call(command, shell=True)
            #print retcode
            if retcode != 0:
                print 'Child was terminated by signal %d' %retcode
                return False
          except OSError, e:
               print MODULE_NAME + ': %s' %e
               return False
 
          return True

    else:
        print 'Unsupported format'

if __name__ == "__main__":
    if len(sys.argv) == 3:
	    tiff_file = sys.argv[1]
	    pdf_file = sys.argv[2]
	    r = export_to_pdf(tiff_file, pdf_file)
	    if r:
		print "Convert successfully"
	    else:
		print "Cannot convert"
		sys.exit(1)
    else:
        print "usage: %s <tiff_file> <pdf_file>" % sys.argv[0]
        sys.exit(1)

