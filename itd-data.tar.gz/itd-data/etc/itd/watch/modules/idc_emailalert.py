#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
try:
	import os
	import subprocess
	import pwd
	import ConfigParser
	import datetime
	from xml.dom import minidom
	from idc_functions import get_xml_value
except Exception, e:
	print "idc_emailalert: [%s]" %e
	sys.exit(0)

MODULE_NAME = 'idc_emailalert'
MAIL_TEMPLATE =  "../template/idc_mail.tmpl"

def get_cloud_configuration(cloud):
	conf_path = "/etc/samba"
	try:
		found = False
		for conffile in os.listdir(conf_path):
			if os.path.splitext(conffile)[1] == ".conf":
				f = open(os.path.join(conf_path, conffile), 'r')
				confdata = f.read()
				f.close()
				f1 = open('/tmp/idc.conf', 'w')
				for line in confdata.split('\n'):
					f1.write(line.strip() + '\n')
				f1.close()
				config = ConfigParser.ConfigParser()
				config.read("/tmp/idc.conf")
				for section in config.sections():
					if section.upper()==cloud.upper():
							found = True
							break
				if found:
					break
	except Exception, e:
		print e
		return None
		
	emaillist = []
	op = 'read list'
	if config.has_option(section, op):
		email = config.get(section,op)
		if email != None and email != "":
			tmp_list=email.split(',')
			for tmp in tmp_list:
				mailtmp=None
				try:
					mailtmp=tmp.replace('"', '')
					mailtmp=tmp.replace('@', '')
				except:
					pass
				if (mailtmp != None) and (mailtmp not in emaillist):
					emaillist.append(mailtmp)
	comment = ""
	if config.has_option(section, "comment"):
		comment = email = config.get(section,"comment")
	return emaillist, comment

def send_email(filelist, cloudpath, cloud, boxid):
	#ret = get_cloud_configuration(cloud)
	#if ret == None:
	#    return
	emaillist = []
	try:
			command = "/usr/bin/ldapsearch -h localhost -LLL -x -w openlab -D \"cn=proxyuser,dc=box%s,dc=idragon,dc=vn\" -b \"ou=Groups,dc=box%s,dc=idragon,dc=vn\" \"cn=%s\" | grep -m 1 \"mailAlternateAddress:\" | cut -d \":\" -f2 | sed -e \"s/^ //g\"" %(boxid,boxid,cloud)
			p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			ret =  p.communicate()
			ret, err = ret
			if err != '':
				ret = ""
			emaillist.append(ret.strip())
	except Exception, e:
				emaillist = []
	clouddesc = ""
	try:
			command = "/usr/bin/ldapsearch -h localhost -LLL -x -w openlab -D \"cn=proxyuser,dc=box%s,dc=idragon,dc=vn\" -b \"ou=Groups,dc=box%s,dc=idragon,dc=vn\" \"cn=%s\" | grep iDCloudName  | cut -d \":\" -f3 | sed -e \"s/^ //g\" | base64 -d" %(boxid,boxid,cloud)
			p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			ret =  p.communicate()
			ret, err = ret
			if err != '':
				ret = ""
			clouddesc = ret.strip()
	except Exception, e:
				clouddesc = ""
			#continue
	#emaillist, clouddesc = ret
	if emaillist == None or emaillist == []:
		print "No email address"
		return
	if clouddesc == "":
		clouddesc = cloud
	emailstr = ""
	for email in emaillist:
		if emailstr == "":
			emailstr = email
		else:
			emailstr = emailstr + " " + email
	#print emailstr
	if not os.path.isfile(MAIL_TEMPLATE):
		return
	f = open (MAIL_TEMPLATE, 'r')
	mail_template = f.read()
	f.close()
	
	lines = []
	try:
		f_tmp = open(filelist, 'r')
		lines = f_tmp.readlines()
		f_tmp.close()
	except:
		lines = []
	maildict = {}
	for line in lines:
		try:
			path, name = line.split("$:$")[0], line.split("$:$")[1]
			name = name.strip()
			path = path.strip()
		except:
			continue
		value = ""
		filetype = "File"
		full_path = os.path.join(path,name)
		try:
			s = os.stat(full_path)
			uid = s.st_uid
			gid = s.st_gid
			admin = pwd.getpwuid(uid).pw_name
		except Exception, e:
			continue
		pathlist = path.split("/")
		if ".content" in pathlist:
			try:
				if os.path.isfile(full_path):
					if os.path.splitext(name)[1] == '.xml':
						doc = minidom.parse(full_path)
						value = get_xml_value(doc, 'TITLE')
						filetype = "Content"
						doc_id = os.path.splitext(name)[0]
					else:
						continue
			except Exception, e:
				print e
				continue
		else:
			value = name
			location = trim_path(cloudpath,path)
			
		if filetype == "Content":
			#http://box116.idragon.vn:1880/1160172/bin/viewimage?ID=135148298276&cloud=1160172&screen=1280x1024
			#http_url="http://box%s.idragon.vn:1880/%s/bin/viewimage?ID=%s&cloud=%s" %(boxid, cloud, doc_id, cloud)
			location="http://www.cloudgate.vn"
			#http_url= http_url.replace(" ","%20")
			#location = "<a href=\"%s\">%s</a>" %(http_url, value)
		else:
			location="http://www.cloudgate.vn"
			#http_url="http://box%s.idragon.vn:1880/%s%s/%s" %(boxid, cloud, location, name)
			#http_url= http_url.replace(" ","%20")
			#location = "<a href=\"%s\">%s</a>" %(http_url, value)
		try:
			command = "/usr/bin/ldapsearch -h localhost -LLL -x -w openlab -D \"cn=proxyuser,dc=box%s,dc=idragon,dc=vn\" -b \"ou=Users,dc=box%s,dc=idragon,dc=vn\" \"uid=%s\" | grep gecos | cut -d \":\" -f2 | sed -e \"s/^ //g\"" %(boxid,boxid,admin)
			p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			ret =  p.communicate()
			ret, err = ret
			if err != '':
				ret = ""
			displayname = ret.strip()
		except Exception, e:
			displayname = "System Admin"
			#continue
		if maildict.has_key(admin):
			maildict[admin].append((clouddesc, location, displayname))
		else:
			maildict[admin] = [(clouddesc, location, displayname)]
		
		
	#print maildict
	for key, values in maildict.items():
		mail_temp = mail_template
		mailtext = ""
		f1 = open('/tmp/idc.mail', 'w')
		for value in values:
			clouddesc, location, displayname = value
			mail_temp = mail_temp.replace("<CloudName>", clouddesc)
			mail_temp = mail_temp.replace("<DocumentLocation>", location)
			mail_temp = mail_temp.replace("<UserName>", "%s (%s)"%(displayname,key))
			now=datetime.datetime.now()
			now = "%s:%s:%s %s/%s/%s" %(now.hour, now.minute, now.second, now.day, now.month, now.year)
			mail_temp = mail_temp.replace("<Time>", now)
			mailtext = mailtext + "----------------------------------------------------------------------" + mail_temp
		f1.write(mailtext)
		f1.close()
		#command = 'su %s -c "/usr/bin/mailx %s -a \'Content-Type: text/html\' -s \\"Có tài liệu mới trên %s\\" < /tmp/idc.mail"' %(key, emailstr, clouddesc)
		command = 'env MAILRC=/dev/null from="support@cloudgate.vn" smtp="smtp.cloudgate.vn" smtp-auth-user="support@cloudgate.vn" smtp-auth-password="idcloud" smtp-auth="login" /usr/bin/mailx -n -s "Có tài liệu mới trên %s" support@cloudgate.vn %s < /tmp/idc.mail' %(clouddesc, emailstr)
		print command
		p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
		ret =  p.communicate()
		ret, err = ret
		if err == '':
			print "An email has been sent to %s" %emailstr
		else:
			print 'Cannot send email to %s' %emailstr

if __name__ == "__main__":
	#HOME = os.getenv('HOME')
	if len(sys.argv) == 5:
		send_email(sys.argv[1], sys.argv[2],sys.argv[3], sys.argv[4])
	else:
		print "usage: %s <filelist> <cloudpath> <cloud> <boxid>" % sys.argv[0]
		sys.exit(0)
