#!/usr/bin/env python
# -*- coding: utf-8 -*-
__author__="dtson"
__date__ ="$04-10-2011$"

import sys
try:
	import os
	from xml.dom import minidom
	import lucene
	#from common_function import is_dir
	#from Module.configuration import *
	import subprocess
	import datetime
	import time 
except Exception, e:
	print "Index_process: Error in importing lib: [%s]" %e
	sys.exit(0)

MODULE_NAME = 'idc_sensorindexing'
LuceneMaxFieldLength = 1048576
#INDEX_LOG = sys.path[0]


def write_to_log(logfile, msg):
	file_path = logfile
	try:
		f = open(file_path,"a")
	except IOError,e:
		raise Exception('Can not open file %s: %s' %(file_path,e))
		return

	text =  datetime.datetime.now().strftime("%Y/%m/%d	%H:%M:%S") + '	%s\n' %msg 
	try:
		f.write(text)
	except IOError,e:
		raise Exception('Can not write file %s: %s' %(file_path,e))
		f.close()
		return
	f.close()
	return   

def is_xml_file_valid(filename):
	name = filename.split('.')[0]
	for i in range(len(name)):
		if name[i].upper() not in ['0', '1', '2','3', '4', '5', '6','7','8', '9', '-', '_','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','T','R','S','T','U','V','W','X','Y','Z']:
			return False
	return True

def is_valid_store_folder(path):
	name = path.strip()
	for i in range(len(name)):
		if name[i] not in ['0', '1', '2','3', '4', '5', '6','7','8', '9']:
			return False
	return True


def indexDocs(lucene_dir, ID, root, path,filename, writer, logfile,md5_str = '' ):
	if path == None or path == '':
		path ='/'
	abs_path = os.path.join(path, filename)
	abs_path = root + abs_path

	indexed_field = read_metadata_field(abs_path)
	
	doc = lucene.Document()
	doc.add(lucene.Field("ID", ID,
						 lucene.Field.Store.YES,
						 lucene.Field.Index.NOT_ANALYZED))
	doc.add(lucene.Field("name", filename,
						 lucene.Field.Store.YES,
						 lucene.Field.Index.NOT_ANALYZED))
	doc.add(lucene.Field("path", path,
						 lucene.Field.Store.YES,
						 lucene.Field.Index.NOT_ANALYZED))
	doc.add(lucene.Field("md5", md5_str,
						 lucene.Field.Store.YES,
						 lucene.Field.Index.NOT_ANALYZED))

	metadata = ''
	#write_to_log(logfile, "indexing metadata fields of file %s" %ID)
	for x in indexed_field:
		name, value = x
		metadata = metadata + name + '$:$' +value + '\n'
		#write_to_log(logfile, "%s" %name)
		#print name
		name = name.upper()
		tmp = name.split(':')

		if "TYPE" in tmp:
			doc.add(lucene.Field(name, value,
							 lucene.Field.Store.NO,
							 lucene.Field.Index.NOT_ANALYZED))
		else:
			doc.add(lucene.Field(name, value,
							 lucene.Field.Store.NO,
							 lucene.Field.Index.ANALYZED))
	fulltext = ''

	doc.add(lucene.Field('metadata', metadata,
					lucene.Field.Store.YES,
					lucene.Field.Index.ANALYZED))

	f = None
	fulltext_path = os.path.splitext(abs_path)[0] + '.txt'
	if os.path.isfile(fulltext_path):
		try:
			f = open(fulltext_path, 'r')
			fulltext = f.read()
			f.close()
		except Exception, e:
			print MODULE_NAME + ' :%s' %e
			if f:
				f.close()

	doc.add(lucene.Field('fulltext', fulltext,
					lucene.Field.Store.NO,
					lucene.Field.Index.ANALYZED))

	writer.addDocument(doc)



def getHitCount(dir, fieldName, searchString):
	searcher = lucene.IndexSearcher(dir)
	t = lucene.Term(fieldName, searchString)
	query = lucene.TermQuery(t)
	hits = searcher.search(query,50).scoreDocs
	hitCount = len(hits)

	md5_str = ''
	if hitCount == 1:
		for hit in hits:
			#doc = lucene.Hit.cast_(hit).getDocument()
			doc = searcher.doc(hit.doc)
			md5_str = doc.get("md5")
	searcher.close()
	return hitCount, md5_str


def read_metadata_field(filename):
	#def get_xml_value(self, doc, name):
	def viewNode(v):

		out = None
		dem = v.childNodes.length
		if dem>1:
			j = 1
			while j < dem:
				w = v.childNodes[j]
				if v.tagName == 'metadata':
					pass
				else:
					out = viewNode(w)
				j = j + 2
		if dem==1:
			temp = v.tagName.upper()
			out = v.firstChild.data
			field_list.append((temp, out))

	#____________________________________________________________
	#print file_name
	#field_name = {'niscidc:title':'Title','niscidc:date':'Date','niscidc:creator':'Creator', 'niscidc:size':'Size','niscidc:about':'About'}
	field_list = []
	doc = minidom.parse(filename)
	count = doc.firstChild.childNodes.length
	u = doc.firstChild
	if count>1:
		i = 1
		while i < count:
			v = u.childNodes[i]
			out = viewNode(v)
			i = i + 2
			#if out != None:
			#   return out

	else:
		temp = u.tagName.upper()
		field_list.append((temp, u.firstChild.data))
	return field_list

def trim_path(root, path):
	r = root.strip()
	p = path.strip()
	i  = p.find(r)
	#print i
	#print p
	if i!= -1:
		#print p[i:]
		return p[i+len(r):]
	else:
		return None


def indexfilelist(root, filelist,index_log):
	logfile = os.path.join(index_log,'index_log.log')
	update = False
	#get list of index folder
	datenow = datetime.date.today()
	yearnow = datenow.year
	monthnow = datenow.month
	monthpast = monthnow - 1
	yearpast = yearnow
	if monthpast < 1:
		monthpast = 12
		yearpast = yearpast - 1
	if monthpast < 10:
		monthpast = "0"+str(monthpast)
	else:
		monthpast = str(monthpast)
	if monthnow < 10:
		monthnow = "0"+str(monthnow)
	else:
		monthnow = str(monthnow)
	pathlist = ["/"+str(yearnow)+"/"+monthnow, "/"+str(yearpast)+"/"+monthpast]
	lines = []
	try:
		f_tmp = open(filelist, 'r')
		lines = f_tmp.readlines()
		f_tmp.close()
	except:
		lines = []
	index_dic = {}
	for line in lines:
		try:
			path, name = line.split("$:$")[0], line.split("$:$")[1]
			name = name.strip()
			path = path.strip()
		except:
			continue
		dickey = None
		
		for pathstr in pathlist:
			i = path.find(pathstr)
			if i != -1:
				dickey = path[:i] + pathstr
				break
		if dickey:
			if index_dic.has_key(dickey):
				index_dic[dickey].append((path,name))
			else: 
				index_dic[dickey] = [(path, name)]
	for key, valuelist in index_dic.items():
		collection_folder = key
		index_folder = os.path.join(collection_folder, ".index")
		if not os.path.exists(index_folder):
			try:
				os.mkdir(index_folder)
			except OSError, e:
				write_to_log(logfile, "cannot create index folder at %s: [%s]" %(index_folder,e))
				return -1
			store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, True)
			writer_parameter = True
			#writer = lucene.IndexWriter(store, analyzer, True)
		elif os.path.isfile(os.path.join(index_folder, "segments.gen")):
			store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, False)
			writer_parameter = False
			update = True
		else:
			store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, True)
			writer_parameter = True
		try:
			writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
		except lucene.JavaError, e:
			if os.path.isfile(os.path.join(index_folder, "write.lock")):
				try:
					os.remove(os.path.join(index_folder, "write.lock"))
					writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
				except Exception, e:
					write_to_log(logfile, "%s" %e)
					return -1
			else:
				return -1
		writer.setMaxFieldLength(LuceneMaxFieldLength)
		for line in valuelist:
			path, name = line
			tmp = os.path.basename(path)
			if not is_valid_store_folder(tmp):
				continue
			if not name.endswith('.xml'):
				continue
			ID = name.split('.')[0]
			if is_xml_file_valid(name):
				filename_abs_path = os.path.join(path, name)
	#				 check permission
				try:
					f = open(filename_abs_path, 'r')
				except IOError, e:
					continue
				f.close()
	#				get md5 of file
				filename_abs_path = filename_abs_path.strip()
				filename_abs_path.replace(' ','\\ ')
				file_md5_str = '1'
				trimpath = trim_path(collection_folder,path) 
				if trimpath != None:
					if update:
						pass
						#num, md5_str = getHitCount(store, 'ID',ID)
						#if num >= 1:
							#t = lucene.Term('ID', ID)
							#if writer != None:
								#writer.close()
							#reader = lucene.IndexReader.open(store)
							#reader.deleteDocuments(t)
							#reader.close()
							#writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter)
							#writer.setMaxFieldLength(LuceneMaxFieldLength)
					try:
						write_to_log(logfile, "indexing %s" %name)
						indexDocs(store, ID, collection_folder, trimpath,name, writer, logfile, file_md5_str )
					except Exception, e:
						write_to_log(logfile, "%s" %e)
						continue

		write_to_log(logfile, "optimizing index store")										
		writer.optimize()
		writer.close()
		filename_abs_path = ""
		for ff in os.listdir(index_folder):
			if ff.endswith('.fdt'):
				filename_abs_path = os.path.join(index_folder, ff)
				break
		filename_abs_path.replace(' ','\\ ')
		try:
			popen = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
			file_md5_str =  popen.communicate()
			file_md5_str, b = file_md5_str
			file_md5_str = file_md5_str.split (' ')[0]
			if len(file_md5_str) != 32:
				file_md5_str = ''
		except Exception, e:
			write_to_log(logfile, "%s" %e)
			file_md5_str = ''
		try:
			file(os.path.join(index_folder, '.md5'),'w+').write("%s\n" % file_md5_str)
		except Exception, e:
			pass
		#print "%d/%d" %(j,i)

def add_cloudtype_to_index(root, cloudtype):
	index_folder = os.path.join(root, ".index")
	if not os.path.exists(index_folder):
		try:
			os.mkdir(index_folder)
		except Exception, e:
			#print e
			write_to_log(logfile, "cannot create index folder")
			return -1
	store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, True)
	writer_parameter = True
	try:
		writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
	except lucene.JavaError, e:
		if os.path.isfile(os.path.join(index_folder, "write.lock")):
			try:
				os.remove(os.path.join(index_folder, "write.lock"))
				writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
			except Exception, e:
				write_to_log(logfile, "%s" %e)
				return -1
		else:
			return -1
	writer.setMaxFieldLength(LuceneMaxFieldLength)
	doc = lucene.Document()
	#no store and un ANALYZED
	doc.add(lucene.Field("CloudType", cloudtype,lucene.Field.Store.YES,lucene.Field.Index.NOT_ANALYZED))
	writer.addDocument(doc)
	writer.optimize()
	writer.close()

def indexfolder(root, indexlog):
	#get list of folder needed index
	index_list = []
	try:
		add_cloudtype_to_index(root, "SensorData")
	except:
		pass

	for year_dir in os.listdir(root):
			if not os.path.isdir(os.path.join(root, year_dir)):
				continue
			if year_dir[0] == ".":
				continue
			if len(year_dir) != 4:
				continue
			if not is_valid_store_folder(year_dir):
				continue
			for mon_dir in os.listdir(os.path.join(root,year_dir)):
				if not os.path.isdir(os.path.join(root, year_dir,mon_dir)):
					continue
				if mon_dir[0] == ".":
					continue
				if len(mon_dir) != 2:
					continue
				if not is_valid_store_folder(mon_dir):
					continue
				full_dir = os.path.join(root, year_dir,mon_dir)
				index_dir = os.path.join(full_dir, ".index")
				if os.path.isfile(os.path.join(index_dir,"segments.gen")):
					datenow = datetime.date.today()
					yearnow = datenow.year
					monthnow = datenow.month
					if int(year_dir) == yearnow and monthnow == int( mon_dir):
						index_list.append((full_dir, index_dir))
				else:
					index_list.append((full_dir,index_dir))
	for folder in index_list:
		fulldir, indexdir = folder
		print fulldir
		Index_folder(fulldir, indexdir, fulldir, indexlog)

def Index_folder(collection_folder, index_folder, indexed_folder,index_log, init_num = 0):
	logfile = os.path.join(index_log,'index_log.log')
	write_to_log(logfile, "indexing %s" %indexed_folder)
	_root = indexed_folder
	update = False
	i = 0
	if not os.path.exists(index_folder):
		try:
			os.mkdir(index_folder)
		except Exception, e:
			#print e
			write_to_log(logfile, "cannot create index folder")
			return -1
	store = lucene.SimpleFSDirectory(lucene.File(index_folder)) #lucene.FSDirectory.getDirectory(index_folder, True)
	writer_parameter = True
	try:
		writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
	except lucene.JavaError, e:
		if os.path.isfile(os.path.join(index_folder, "write.lock")):
			try:
				os.remove(os.path.join(index_folder, "write.lock"))
				writer = lucene.IndexWriter(store, lucene.StandardAnalyzer(lucene.Version.LUCENE_CURRENT), writer_parameter, lucene.IndexWriter.MaxFieldLength.LIMITED)
			except Exception, e:
				write_to_log(logfile, "%s" %e)
				return -1
		else:
			return -1
	writer.setMaxFieldLength(LuceneMaxFieldLength)
	for root, dirnames, filenames in os.walk(_root):
		#print root
		tmp = os.path.basename(root)
		if not is_valid_store_folder(tmp):
			continue
		for filename in filenames:
			if not filename.endswith('.xml'):
				continue
			ID = filename.split('.')[0]
			if is_xml_file_valid(filename):
				i = i + 1
				filename_abs_path = os.path.join(root, filename)
#				 check permission
				try:
					f = open(filename_abs_path, 'r')
				except IOError, e:
					continue
				f.close()
#				get md5 file
				filename_abs_path = filename_abs_path.strip()
				filename_abs_path.replace(' ','\\ ')
				path = trim_path(collection_folder,root) 
				if path != None:
					try:
						file_md5_str = "1"
						indexDocs(store, ID, collection_folder, path,filename, writer, logfile, file_md5_str )
					except Exception, e:
						write_to_log(logfile, "%s: %s" %(filename_abs_path,e))
						continue
	write_to_log(logfile, "optimizing index store")										
	writer.optimize()
	writer.close()
	write_to_log(logfile, "Cleaning index store")
	filename_abs_path = ""
	for ff in os.listdir(index_folder):
		if ff.endswith('.fdt'):
			filename_abs_path = os.path.join(index_folder, ff)
			break
	filename_abs_path.replace(' ','\\ ')
	try:
		popen = subprocess.Popen (['md5sum', filename_abs_path], shell = False, stdout=subprocess.PIPE)
		file_md5_str =  popen.communicate()
		file_md5_str, b = file_md5_str
		file_md5_str = file_md5_str.split (' ')[0]
		if len(file_md5_str) != 32:
			file_md5_str = ''
	except Exception, e:
		write_to_log(logfile, "%s" %e)
		file_md5_str = ''
	try:
		file(os.path.join(index_folder, '.md5'),'w+').write("%s\n" % file_md5_str)
	except Exception, e:
		pass
	print i

if __name__ == "__main__":
	if len(sys.argv) == 3 or len(sys.argv) == 4:
		lucene.initVM(lucene.CLASSPATH)
		#index_process(path, file_name, index_folder, root, index_log)
		USER = os.getenv('USER')
		indexlog = '/tmp/' + USER
		if not os.path.isdir(indexlog):
			os.mkdir(indexlog)
		#print indexlog
		if sys.argv[1].upper() == 'INDEXFILELIST':
			indexfilelist(sys.argv[2], sys.argv[3], indexlog)
		elif sys.argv[1].upper() == 'INDEXFOLDER':
			indexfolder(sys.argv[2], indexlog)
			#collection_folder, index_folder, indexed_folder,index_log
		#elif sys.argv[1].upper() == 'CLEANINDEX':
		#	clean_index(sys.argv[3], sys.argv[4], os.path.join(indexlog,'index_log.log'))

		else:
			print "unknow option"
			sys.exit(2)
	else:
		print "usage: %s indexfilelist <root> <filelist>" % sys.argv[0]
		print "usage: %s indexfolder <root>" % sys.argv[0]
		#print "usage: %s cleanindex <root> <index_folder> <indexed_folder> <index_log> 0" % sys.argv[0]

		sys.exit(1)
