#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xml
from xml.dom import minidom
import sys, os
import ldap
import ldap.modlist as modlist

BASEDN = "dc=idragon,dc=vn"
PROXYUSER = "cn=proxyuser,ou=Admins," + BASEDN
PROXYUSER_PASS = "openlab9002"
LDAP_SERVER = "127.0.0.1"
LDAP_PORT = 10389

def remove_dir(path):
	try:
		for root, folders, files in os.walk(path):
			for name in files:
				os.remove(os.path.join(root,name))
			for name in folders:
				os.rmdir(os.path.join(root,name))
		os.rmdir(path)
	except Exception,e:
		print e
		pass

def get_xml_value(doc, name):
	def viewNode(v):
		out = None
		dem = v.childNodes.length
		if dem>1:
			j = 1
			while j < dem:
					w = v.childNodes[j]
					if v.tagName == 'metadata':
						pass
					else:
						out = viewNode(w)
					j = j + 2
					if out != None:
						return out
		if dem==1:
			temp = v.tagName.upper()
			temp = temp.split(':')
			if name.upper() in temp:
				out = v.firstChild.data
				try:
					if name.upper() == 'SIZE':
						tmp_size = float(out)/1024/1024
						if tmp_size < 1:
							tmp_size = float(out)/1024
							tmp_size = '%.2f KB' %tmp_size
						else:
							tmp_size = '%.2f MB' %tmp_size
						out = tmp_size
				except Exception, e:
					print MODULE_NAME + ': %s' %e
					out = 'N/A'
				#print out
			else:
				out = None
		return out
		#____________________________________________________________

	count = doc.firstChild.childNodes.length
	u = doc.firstChild
	if count>1:
		i = 1
		while i < count:
			v = u.childNodes[i]
			out = viewNode(v)
			i = i + 2
			if out != None:
				return out.encode("utf-8")
	else:
		return u.firstChild.data.encode("utf-8")

def trim_path(root, path):
	r = root.strip()
	p = path.strip()
	i = p.find(r)
	if i!=-1:
		return p[i+len(r):]
	else:
		return ""


def reference_infor(usfilter,retrieve, base=None):
	#BASEDN = "dc=idragon,dc=vn"
	if base == None:
		BASEDNSEARCH = BASEDN
	else:
		#BASEDNSEARCH = "dc=" + base + "," + BASEDN
		BASEDNSEARCH = base + "," + BASEDN

	ll = ldap.open(LDAP_SERVER,int(LDAP_PORT))
	try:
		ll.simple_bind(PROXYUSER,PROXYUSER_PASS)
	except Exception,error_message:
		msg = "Status: 401 Unauthorized"
		msg = str(error_message)
		return msg

	scope = ldap.SCOPE_SUBTREE
	#retrieve_attributes = retrieve

	result_set=[]
	timeout = 0
	try:
		result_id = ll.search(BASEDNSEARCH,scope,usfilter,retrieve)
		while 1:
			result_type, result_data = ll.result(result_id, timeout)
			if (result_data == []):
				break
			else:
				if result_type == ldap.RES_SEARCH_ENTRY:
					#print result_data
					result_set.append(result_data)
		return result_set
	except ldap.LDAPError, error_message:
		#print error_message
		msg = str(error_message)
		return msg


def get_device_ip(deviceid):
	try:
		uid = deviceid
		limit = "uid=%s" %uid
		attrs=['iDDevicePrimaryContactURI']
		base = "ou=Devices,ou=Clouds"
		ret = reference_infor(limit, attrs, base)
		if type(ret) == str:
			print ret
			return None
		result = None
		for x in ret:
			dicts = x[0][1]
			if dicts.has_key('iDDevicePrimaryContactURI'):
				value = dicts['iDDevicePrimaryContactURI']
				result = value[0]
		return result
	except Exception, e:
		#print e
		return None
def get_cloud_info(cloudid,cloudtype, boxid):
	try:
		if cloudtype == "personal":
			base = "ou=Users,dc=box%s" %boxid
			limit = "uid=%s" %cloudid
			attrs=['iDAccountName']
			ret = reference_infor(limit, attrs, base)
			if type(ret) == str:
				print ret
				return None
			for x in ret:
				dicts = x[0][1]
				if dicts.has_key('iDAccountName'):
					value = dicts['iDAccountName']
				else:
					value = [cloudid]
				return "personal",value[0],cloudid, None
		else:
			base = "ou=Groups,dc=box%s" %boxid
			limit = "cn=%s" %cloudid
			attrs=['iDCloudStatus', 'iDCloudName', 'iDCloudPrimaryMember', 'confirmtext']
			#print base
			#cloudtype2, clouddesc, admin, password
			ret = reference_infor(limit, attrs, base)
			if (type(ret) == str or ret == []):
			    base = "ou=Storage,ou=Clouds"
			    limit = "cn=%s" %cloudid
			    attrs=['iDCloudStatus', 'iDCloudName', 'iDCloudPrimaryMember', 'confirmtext']
			    ret = reference_infor(limit, attrs, base)
			    if type(ret) == str:
				return None
			result = []
			for x in ret:
				dicts = x[0][1]
				for a in attrs:
					if dicts.has_key(a):
						value = dicts[a]
						result.append(value[0])
			if len(result) == 3:
				result.append("openlab")
			if len(result) == 4:
				return result[0],result[1],result[2],result[3]
			else:
				return None
	except Exception, e:
		print e
		return None
def get_cloud_info2(cloudid):
	try:
		#base = "ou=Groups,dc=box%s" %boxid
		limit = "cn=%s" %cloudid
		attrs=['iDCloudStatus', 'iDCloudName', 'iDCloudPrimaryMember', 'confirmtext']
		#cloudtype2, clouddesc, admin, password
		ret = reference_infor(limit, attrs)
		if type(ret) == str:
			print ret
			return None
		result = []
		for x in ret:
			dicts = x[0][1]
			for a in attrs:
				if dicts.has_key(a):
					value = dicts[a]
					result.append(value[0])
		if len(result) == 3:
			result.append("openlab")
		if len(result) == 4:
			return result[0],result[1],result[2],result[3]
		else:
			return None
	except Exception, e:
		print e
		return None

def get_collection(root, filename):
        def xml_parser(doc_, init_space = ''):
            _doc = doc_
            list_temp = []
	    DisplayField = []
	    Desc = ""
	    ID = ""
            if _doc.hasChildNodes():
			ID = ""
			Desc = ""
			DisplayField = []
			rlist = []
			childs = _doc.childNodes
			for child in childs:
				if 1: #child.nodeType == child.ELEMENT_NODE:
					r = xml_parser(child, init_space + '...')
					if r == None:
						continue
				        if _doc.tagName == 'Store':
						rlist.append(r)
					elif _doc.tagName == 'Collections':
						rlist.append(r)
				        elif _doc.tagName == 'Collection':
						t_name, v = r
						if t_name == 'Description':
							Desc = v
						if t_name == 'ID':
							ID = v
						if t_name == 'DisplayField':
							DisplayField.append(v)
					elif _doc.tagName == 'Description':
					     list_temp = _doc.tagName, r
					elif _doc.tagName == 'ID':
					     list_temp = _doc.tagName, r
					elif _doc.tagName == 'DisplayField':
					     list_temp = _doc.tagName, r
				else:
					continue
			if _doc.tagName == 'Store':
				list_temp.append([root, _doc.getAttribute('desc'), _doc.getAttribute('id'),"", "", rlist])
			elif _doc.tagName == 'Collections':
				list_temp = [root, _doc.getAttribute('desc'), "","","", rlist]
		        elif _doc.tagName == 'Collection':
				list_temp = (root, Desc, ID, DisplayField)
	    else:
			if _doc.data.strip() != "":
				list_temp = _doc.data
			else:
				list_temp = None
            return list_temp
        #____________________________________________________________
        #try:
        #  doc = minidom.parse(filename)
        #except Exception, e:
        #  print MODULE_NAME + ': %s' %e
        #  return -1
	try:
		doc = minidom.parse(os.path.join(root,filename))
		if doc == None:
		    return -1
		u = doc.firstChild
		ret = xml_parser(u)
		#print ret
		return ret
	except Exception, e:
		print e
		return -1

def get_all_collection_id(path):
    def get_id(collection):
	ret = []
	for x in collection:
	    if type(x) == list:
		ret_tmp = get_id(x)
		ret = ret + ret_tmp
	    elif type(x) == tuple:
		ret.append(x[2])
		continue
	    else:
		continue
	return ret
    retlist = []
    try:
	tmp = get_collection("",path)
	retlist = get_id(tmp)
	return retlist
    except:
	return -1


if __name__ == "__main__":
    print get_all_collection_id("/export/public/1140350/VanBan2013/.content/collection.xml")


