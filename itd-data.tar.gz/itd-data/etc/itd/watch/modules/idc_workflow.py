#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
try:
	import os
	import subprocess
	import pwd
	import subprocess
	import ConfigParser
	import logging
	import datetime
	import time
	import shutil
	from xml.dom import minidom
	from xmllib import save_xmllib
	from idc_functions import get_device_ip,get_cloud_info,get_cloud_info2, remove_dir
except Exception, e:
	print "idc_workflow: [%s]" %e
	sys.exit(0)

MODULE_NAME = 'idc_workflow'
MAIL_TEMPLATE =  "../template/idc_mail.tmpl"


def do_workflow(filelist, cloudpath, cloud, boxid):
	lines = []
	try:
		f_tmp = open(filelist, 'r')
		lines = f_tmp.readlines()
		f_tmp.close()
	except:
		lines = []

	for line in lines:
		try:
			path, name = line.split("$:$")[0], line.split("$:$")[1]
			name = name.strip()
			path = path.strip()
		except:
			continue
		full_path = os.path.join(path,name)
		collection = ""
		SendTo = ""
		SendToDate = ""
		try:
			if os.path.isfile(full_path):
				if os.path.splitext(name)[1] == '.xml':
					doc = minidom.parse(full_path)
					collection = get_xml_value(doc, 'Source.Collection')
					SendToDate = get_xml_value(doc, 'Date', 'Coverage.To')
					SendTo = get_xml_value(doc, 'URL', 'Coverage.To')
					if type(SendTo) == str:
						SendTo = SendTo.strip()
					if type(SendToDate) == str:
						SendToDate = SendToDate.strip()
				else:
					continue
		except Exception, e:
			print e
			continue
		if collection:
			print "read workflow from collection.xml"
			#read workflow from collection.xml
			#read steps from workflow definition file
		print "try sendto: %s" %SendTo
		if SendTo:
			if SendToDate == "":
				print SendTo
				#copy to temp dir
				docID = os.path.basename(path)
				tmpdir = ""
				SendList = SendTo.split(",")
				for sendadd in SendList:
					tmp = sendadd.strip()
					try:
						cloudid = tmp.split("@")[0]
						serverid = tmp.split("@")[1]
						ip = get_device_ip(serverid)
						ret = get_cloud_info2(cloudid)
						print ip
						print ret
						if ret == None or ip == None:
							continue

						try:
							tmpdir = "/tmp/%s" %docID
							shutil.copytree(path, tmpdir)
							tmpfile = os.path.join(tmpdir,"%s.xml" %docID)
							#change metadata
							xmldata = {}
							xmldata["URL"] = cloud
							save_xmllib(tmpfile, tmpfile, xmldata, "DC:Coverage.From")
							#change doc type
							#doc_type = cloudid[0:3]+"0000"
							#xmldata = {}
							#xmldata["DC:Type"] = doc_type
							#save_xmllib(tmpfile, tmpfile, xmldata)
							#remove send to infor
							xmldata = {}
							xmldata["URL"] = ""
							save_xmllib(tmpfile, tmpfile, xmldata, "DC:Coverage.To")
						except Exception,e :
							print e
							print '%s: Cannot change metadata' %cloud
							#delete tmp file
							remove_dir(tmpdir)
							continue

						cloudtype2, clouddesc, admin, passwd = ret
						ret = SendDoc(tmpdir,cloud, cloudid,path, ip, admin, passwd)
						print ret
						if ret:
							print "file %s has been sent to %s@%s(%s) via rsync" %(name,cloudid,serverid,ip)
						remove_dir(tmpdir)
					except Exception, e:
						#delete tmp file
						remove_dir(tmpdir)
						print e
						continue
		else:
		    print "Nothing to do with workflow"
		#call do_workflow

def SendDoc(tmpdir, cloudsrc,clouddest, full_path, rsync_add, rsync_user, rsync_passwd):
	try:
		rsync_IP = rsync_add.split(":")[0]
		rsync_port = rsync_add.split(":")[1]
	except:
		rsync_IP = rsync_add
		rsync_port = "873"
	if cloudsrc.find("-:-") != -1:
	    cloudsrcid = cloudsrc.split("-:-")[0]
	    s_i = full_path.find(cloudsrcid)
	    
	else:
	    cloudsrcid = cloudsrc
	    s_i = full_path.find(cloudsrcid)
	command = ""
	if s_i != -1:
		sourceDir = full_path[s_i+len(cloudsrcid):]
		path_split = sourceDir.split("/.content")
		share = clouddest +  "/Upload/.content"
		timeUnix = int(time.time())
		source = "/tmp/" + str(timeUnix) + path_split[1]
		shutil.copytree(tmpdir, source)
		sourcePath = "/tmp/" + str(timeUnix)
		try:
			command = 'export RSYNC_PASSWORD=%s;/usr/bin/rsync -au %s/* %s@%s::%s --port=%s' %(rsync_passwd, sourcePath, rsync_user, rsync_IP, share, rsync_port)
		except:
			print '%s: Cannot execute rsync' %cloudsrc
			return False
	else:
		print '%s: Error: Cannot find the path for rsync' %cloudsrc
		return False
	print command
	if command != "":
		p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
		ret =  p.communicate()
		ret, err = ret
		if err != '':
			print '%s: Cannot execute rsync: %s' %(cloudsrc,err)
			return False
		return True
	else:
		return False



def get_xml_value(doc, name, P = None):
	def viewNode(v):
		out = None
		dem = v.childNodes.length
		if dem>1:
			j = 1
			while j < dem:
					w = v.childNodes[j]
					if v.tagName == 'metadata':
						pass
					else:
						out = viewNode(w)
					j = j + 2
					if out != None:
						return out
		if dem==1:
			temp = v.tagName.upper()
			temp = temp.split(':')
			if name.upper() in temp:
				if P:
					pNode = v.parentNode
					if pNode != None:
						pname = str(pNode.nodeName)
						pname = pname.upper().split(':')
						if P.upper() not in pname:
							return None
				out = v.firstChild.data
				try:
					if name.upper() == 'SIZE':
						tmp_size = float(out)/1024/1024
						if tmp_size < 1:
							tmp_size = float(out)/1024
							tmp_size = '%.2f KB' %tmp_size
						else:
							tmp_size = '%.2f MB' %tmp_size
						out = tmp_size
				except Exception, e:
					print MODULE_NAME + ': %s' %e
					out = 'N/A'
				#print out
			else:
				out = None
		return out
		#____________________________________________________________

	count = doc.firstChild.childNodes.length
	u = doc.firstChild
	if count>1:
		i = 1
		while i < count:
			v = u.childNodes[i]
			out = viewNode(v)
			i = i + 2
			if out != None:
				return out.encode("utf-8")
	else:
		return u.firstChild.data.encode("utf-8")


if __name__ == "__main__":
	#HOME = os.getenv('HOME')
	if len(sys.argv) == 5:
		do_workflow(sys.argv[1], sys.argv[2],sys.argv[3], sys.argv[4])
	else:
		print "usage: %s <filelist> <cloudpath> <cloud> <boxid> <admin>" % sys.argv[0]
		sys.exit(0)
