#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__="dtson"
__date__ ="$19-09-2011$"

import sys
import os
import time
import ConfigParser
import pwd
import subprocess
from modules.idc_functions import get_cloud_info
USER_HOME = os.getenv('HOME')

# set global parmeters
app_name = "iDragon Clouds watching service"
app_version = "1.0"
author_name = "Dương Thái Sơn"
author_email = "dtson@nisci.gov.vn"
home_page = "http://www.nisci.gov.vn"
copyright = author_name + " " + author_email
comments = " "

PROG_PATH = sys.path[0]
MODULE_PATH = PROG_PATH + "/modules"
#conf_path = "/etc/samba"
MAX_INOTIFY_WATHCHES = "100000"
def is_valid_store_folder(path):
    try:
	name = path.strip()
	if len(name) != 4:
	    return False
	for i in range(len(name)):
		if name[i] not in ['0', '1', '2','3', '4', '5', '6','7','8', '9']:
			return False
    except:
	return False
    return True

def read_configuration():
	BOXID = "netbox"
	return_list = []
	cloud_dict = {}
	#get configuration from /conf/.CloudBox/cloudbox.conf
	try:
		f = open('/conf/.CloudBox/cloudbox.conf', 'r')
		confdata = f.read()
		f.close()
	except Exception,e:
		confdata = ""
	paralist = ["public_clouds_index_content",
			"public_clouds_index_file",
			"public_clouds_index_sensor",
			"public_clouds_emailalert",
			"public_clouds_rsync",
			"public_clouds_smb",
			"private_clouds_index_content",
			"private_clouds_index_file",
			"private_clouds_index_sensor",
			"private_clouds_emailalert",
			"private_clouds_rsync",
			"personal_clouds_index_content",
			"personal_clouds_index_file",
			"personal_clouds_index_sensor",
			"personal_clouds_emailalert",
			"personal_clouds_rsync"]
	paradict = {"public_clouds_index_content":"index",
			"public_clouds_index_file":"indexfile",
			"public_clouds_index_sensor":"sensorindex",
			"public_clouds_emailalert":"emailalert",
			"public_clouds_rsync":"rsync",
			"public_clouds_smb":"smb",
			"private_clouds_index_content":"index",
			"private_clouds_index_file":"indexfile",
			"private_clouds_index_sensor":"sensorindex",
			"private_clouds_emailalert":"emailalert",
			"private_clouds_rsync":"rsync",
			"personal_clouds_index_content":"index",
			"personal_clouds_index_file":"indexfile",
			"personal_clouds_index_sensor":"sensorindex",
			"personal_clouds_emailalert":"emailalert",
			"personal_clouds_rsync":"rsync"}
	if confdata != "":
		for x in confdata.split("\n"):
			for para in paralist:
				#print para
				if x.find(para) != -1:
					try:
						tmp = x.split(":")[1]
						tmp = tmp.replace(" ","")
						if tmp == "''":
							continue
						cloudidlist = tmp.strip().split("'")[1]
						cloudidlist = cloudidlist.split(",")
						if "personal" in para:	
							cloudtype = "personal"
						if "private" in para:	
							cloudtype = "private"
						if "public" in para:	
							cloudtype = "public"
						for cloudid in cloudidlist:
							if cloudid.find(":") != -1:
								try:
									_cloudid = cloudid.split(":")[0].strip()
								except:
									continue
							else:
								_cloudid = cloudid.strip()
							#print _cloudid
							if cloud_dict.has_key(_cloudid):
								cloud_dict[_cloudid][0] = cloud_dict[_cloudid][0] + "," + paradict[para]
							else:
								cloud_dict[_cloudid] = [paradict[para], cloudtype]
					except Exception, e:
						print e
						print "Cannot get configuration for %s" %para
						continue
						#return []

				if x.find("boxID") != -1:
					tmp = x.split(":")[1].strip()
					BOXID = tmp.split("'")[1]
	if not BOXID:
		print "Cannot find boxid"
		return []
	#print cloud_dict
	try:
		for key, value in cloud_dict.items():
			#print BOXID
			ret = get_cloud_info(key,value[1], BOXID)
			print ret
			if ret != None:
				cloudtype2, clouddesc, admin, passwd = ret
				cloudtype2 = cloudtype2.lower()
				cloudname = key
				services = value[0]
				cloudtype = value[1]				
				if cloudtype == "personal":
					cloudpath = "/export/users/%s/iDragonCloud" %cloudname
				else:
					if cloudtype.upper() != cloudtype2.upper():
						print "[Warning]: cloud %s has different cloud type. ldap: %s conf:%s" %(key,cloudtype2, cloudtype)
					cloudpath = "/export/%s/%s" %(cloudtype2,cloudname)
				#print cloudpath
				admin2 = ""
				if os.path.isdir(cloudpath):
					try:
						s = os.stat(cloudpath)
						uid = s.st_uid
						gid = s.st_gid
						admin2 = pwd.getpwuid(uid).pw_name
					except Exception, e:
						print "\t\tCannot get owner of cloud"
						print "\t\t%s" %e
				if admin != admin2:
					print "[Warning]: cloud %s has different cloud owner. ldap: %s conf:%s" %(key,admin, admin2)
					admin = admin2
				if cloudname and cloudpath and admin:
					services_list = services.upper().split(",")
					if  ("INDEX" in services_list) and ("SENSORINDEX" in services_list) and ("INDEXFILE" in services_list):
						print "Warning: Only apply one indexing service for each cloud"
						services = "sensorindex"
					elif  ("INDEX" in services_list) and ("INDEXFILE" in services_list):
						print "Warning: Only apply one indexing service for each cloud"
						services = "index"
					elif  ("INDEX" in services_list) and ("SENSORINDEX" in services_list):
						print "Warning: Only apply one indexing service for each cloud"
						services = "sensorindex"
					elif  ("INDEXFILE" in services_list) and ("SENSORINDEX" in services_list):
						print "Warning: Only apply one indexing service for each cloud"
						services = "sensorindex"
					services_list = services.upper().split(",")
					is_index_service_apply = False
					for service in services_list:
						if service == "INDEX":
							#check .content folder
							if os.path.isdir(os.path.join(cloudpath,".content")):
								break
							else:
								for x in os.listdir(cloudpath):
									if os.path.isdir(os.path.join(cloudpath,x,".content")):
										return_list.append((cloudname+"-:-"+x, clouddesc+"("+x+")", os.path.join(cloudpath,x), admin, passwd,services))
										is_index_service_apply = True
						if service == "SENSORINDEX":
							b=False
							for x in os.listdir(cloudpath):
								if os.path.isdir(os.path.join(cloudpath,x)):
								    if (is_valid_store_folder(x)):
									b=True
							if b:
							    break
							for x in os.listdir(cloudpath):
								if os.path.isdir(os.path.join(cloudpath,x)):
								    try:
									if x[0] in [".","~"]:
									    continue
    									return_list.append((cloudname+"-:-"+x, clouddesc+"("+x+")", os.path.join(cloudpath,x), admin, passwd,services))
									is_index_service_apply = True
								    except:
									continue
					if not is_index_service_apply:
						return_list.append((cloudname, clouddesc, cloudpath, admin, passwd,services))
	except Exception, e:
		print "Cannot read configuration: %s" %e
		return []
	return return_list

def start():
	#start service
	cloudlist = read_configuration()
	old_cloudname = ""
	for cloud in cloudlist:
		cloudname, clouddesc, cloudpath, admin, passwd, run = cloud
		command = '%s/idc_daemon.py start %s %s %s %s "%s"' %(PROG_PATH, cloudname, cloudpath, admin, passwd, run)
		#command = 'ls'
		print command
		p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
		ret =  p.communicate()
		#print ret
		ret, err = ret
		if err != '':
			status = "NotOK"
		else:
			status = "OK"
		print "start watching service for cloud %s(%s): \t%s"  %(cloudname, clouddesc, status)
		if status == "NotOK":
			print err
		if run == "index" or run == "sensorindex":
		    cloudname = cloudname.split("-:-")[0]
		    #cloudpath = os.path.dirname(cloudpath) + "/"
		    if cloudname != old_cloudname:
			command = '%s/DDRSer.py start %s %s' %(PROG_PATH, cloudname, cloudpath)
			#command = 'ls'
			print command
			p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
			ret =  p.communicate()
			#print ret
			ret, err = ret
			if err != '':
			    status = "NotOK"
			else:
			    status = "OK"
			print "start store service for cloud %s(%s): \t%s"  %(cloudname, clouddesc, status)
			if status == "NotOK":
			    print err
		    old_cloudname = cloudname


def stop():
	#stop service
	cloudlist = read_configuration()
	old_cloudname = ""
	for cloud in cloudlist:
		cloudname, clouddesc, cloudpath, admin, passwd, run = cloud
		command = '%s/idc_daemon.py stop %s' %(PROG_PATH, cloudname)
		print command
		p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
		ret =  p.communicate()
		ret, err = ret
		#print ret
		if err != '':
			status = "NotOK"
		else:
			status = "OK"
		print "stop watching service for cloud %s(%s)\t%s"  %(cloudname, clouddesc, status)
		if status == "notOK":
			print err
		#stop DDRService
		cloudname = cloudname.split("-:-")[0]
		if cloudname != old_cloudname:
		    command = '%s/DDRSer.py stop %s' %(PROG_PATH, cloudname)
		    print command
		    p = subprocess.Popen (command, shell = True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
		    ret =  p.communicate()
		    ret, err = ret
		    #print ret
		    if err != '':
			status = "NotOK"
		    else:
			status = "OK"
		    print "stop DDR service for cloud %s(%s)\t%s"  %(cloudname, clouddesc, status)
		    if status == "notOK":
			print err
		    old_cloudname = cloudname
	#try to kill all idc_daemon
	os.system('%s/killalldaemon' %MODULE_PATH)
def restart():
		"""
		Restart the daemon
		"""
		stop()
		time.sleep(1)
		start()

if __name__ == "__main__":
	if len(sys.argv) == 2:
		try:
			f=open("/proc/sys/fs/inotify/max_user_watches")
			max_watches=f.read()
			f.close()
			if int(max_watches) < MAX_INOTIFY_WATHCHES:
				os.system('echo %s > /proc/sys/fs/inotify/max_user_watches' %MAX_INOTIFY_WATHCHES)
		except Exception,e:
			print "[WARNING] Cannot reconfig inotify max_user_watches"
		if 'start' == sys.argv[1]:
			start()
		elif 'stop' == sys.argv[1]:
			stop()
		elif 'restart' == sys.argv[1]:
			restart()
		else:
			print "Unknown command"
			sys.exit(2)
		sys.exit(0)
	else:
		print "usage: %s start|stop|restart" % sys.argv[0]
		sys.exit(2)
