#!/usr/bin/perl
####################################################################
# iThunderClouds Software
# Copyright (C) 2014-2016 by Thien Minh Management JS Co. All Rights Reserved.
# Creator: Hoang Le Minh <hlminh@cloudgate.vn>
# Version:6.5
# Last updated: 30 Aug 2016
####################################################################
use Net::LDAP;
my $base = "%CloudBox{cloudbox.general.base}%";
my $orgID = "%CloudBox{cloudbox.general.base_ou}%";
my $boxID = "%CloudBox{cloudbox.general.boxID}%";
my $baseID = "%CloudBox{cloudbox.general.baseID}%";
my $hostID = "%CloudBox{cloudbox.general.hostID}%";
my $domainID = "%CloudBox{cloudbox.general.domainID}%";
my $sambaDomain = "%CloudBox{cloudbox.samba.workgroup}%";
my $ldapserver = "127.0.0.1:389";
my $grpbase = "ou=Groups,$baseID";
my $usrbase = "ou=Users,$baseID";
my $boxbase = "ou=Boxes,ou=$orgID,$baseID";
my $ldapuser = "cn=manager,$base";
my $ldappwd = "openlab8002";
my $ldap  = Net::LDAP -> new($ldapserver) || die "$@";
my $mesg = $ldap -> bind($ldapuser, password => $ldappwd);
if ( "%CloudBox{cloudbox.samba.auto}%" eq "yes" ) {
    open(AUT,"> /etc/idc_samba_auto");
}

my $grpfilter = "(&(objectClass=posixGroup)(bounceadmin=$sambaDomain)(|(iDCloudPrimaryType=Storage)(iDCloudPrimaryType=DigitalContents)))";
my $grpattrs = ["cn","gidNumber"];
$mesg = $ldap -> search(
    base => $grpbase,
    scope => "one",
    filter => $grpfilter,
    attrs => $grpattrs
    );

$mesg -> code && die $mesg -> error;
my @grpentries = $mesg -> all_entries;
my %group_name;

foreach my $entry (@grpentries) {
    my $gidnum = $entry -> get_value("gidNumber");
    my $gname = $entry -> get_value("cn");
    $group_name{$gidnum} = $gname;
}

# Checking Users
my $usrfilter = "(|(ou=$sambaDomain:active)(ou=$sambaDomain:sensor))";
my $usr_uids = "%CloudBox{cloudbox.network.personal_uids}%";
if ( $usr_uids ne "" ) {
    my @usr_uids_list = split(/,/,$usr_uids);
    my @usrcl;

    foreach my $cl (@usr_uids_list) {
	push(@usrcl,"(uid=$cl)");
    }

    my $usrflt_cl = "|";
    foreach my $fcl (@usrcl) {
	$usrflt_cl .= $fcl;
    }
    $usrfilter = "(&(|(ou=$sambaDomain:active)(ou=$sambaDomain:sensor))($usrflt_cl))";
}
my $usrattrs = ["uidNumber","iDAccountName","iDAccountPrimaryContactURI","ou","uid"];

$mesg = $ldap -> search(
    base => $usrbase,
    scope => "one",
    filter => $usrfilter,
    attrs => $usrattrs
);

$mesg -> code && die $mesg -> error;
my @usrentries = $mesg -> all_entries;

# Making SMB Personal Clouds
if ( "%CloudBox{cloudbox.network.samba_server}%" eq "yes" ) {
    open(USR,"> /etc/samba/personal.conf");
    foreach my $entry (@usrentries) {
	my $userDN = $entry -> dn;
	my ($dnstr,$basestr) = split(",",$userDN);
	my ($dn,$cloud) = split("=",$dnstr);
	my $data_box = $entry -> get_value("iDAccountPrimaryContactURI");
	my $comment = $entry -> get_value("iDAccountName");
	print USR "[$cloud]\n";
	print USR "comment = $comment\n";
	print USR "browseable = no\n";
	print USR "read only = no\n";
	print USR "locking = no\n";
	print USR "path = /export/users/$cloud/iDragonCloud\n";
	print USR "guest ok = no\n";
	print USR "create mask = 0640\n";
	print USR "directory mask = 0750\n";
	print USR "valid users = $cloud\n";
	print USR "write list = $cloud\n";
	#print USR "admin users = $cloud\n";
	print USR "vfs objects = full_audit\n";
	print USR "root preexec = /etc/idc_services connect $data_box users $cloud\n" unless "$data_box" eq "$hostID";
	if ( "%CloudBox{cloudbox.samba.auto}%" eq "yes" ) {
	    print AUT "/bin/echo \"Checking and mounting personal $cloud cloud...\"\n" unless "$data_box" eq "$hostID";
	    print AUT "/etc/idc_services connect $data_box users $cloud\n" unless "$data_box" eq "$hostID";
	}
	print USR "root postexec = /etc/idc_services disconnect $data_box users $cloud\n" unless "$data_box" eq "$hostID";
	print USR "\n";
    }
    close(USR);
}

# Checking Private Clouds
my $prifilter = "(&(iDCloudStatus=Private)(bounceadmin=$sambaDomain)(|(iDCloudPrimaryType=Storage)(iDCloudPrimaryType=DigitalContents)))";
my $private_clouds = "%CloudBox{cloudbox.network.private_clouds}%";
if ( $private_clouds ne "" ) {
    my @private_clouds_list = split(/,/,$private_clouds);
    my @pricl;
    foreach my $cl (@private_clouds_list) {
	push(@pricl,"(cn=$cl)");
    }
    my $priflt_cl = "|";
    foreach my $fcl (@pricl) {
	$priflt_cl .= $fcl;
    }
    $prifilter = "(&(iDCloudStatus=Private)($priflt_cl)(bounceadmin=$sambaDomain)(|(iDCloudPrimaryType=Storage)(iDCloudPrimaryType=DigitalContents)))";
}
my $priattrs = ["gidNumber","cn","iDCloudName","iDCloudStatus","iDCloudPrimaryProviderURI","iDCloudPrimaryMember"];
$mesg = $ldap -> search(
    base => $grpbase,
    scope => "one",
    filter => $prifilter,
    attrs => $priattrs
);

$mesg -> code && die $mesg -> error;
my @prientries = $mesg -> all_entries;

# Making SMB Private Clouds
if ( "%CloudBox{cloudbox.network.samba_server}%" eq "yes" ) {
    open(PRI,"> /etc/samba/private.conf");
    foreach my $entry (@prientries) {
	my $cloud = $entry -> get_value("cn");
	my $comment = $entry -> get_value("iDCloudName");
	my $owner = $entry -> get_value("iDCloudPrimaryMember");
	my $data_box = $entry -> get_value("iDCloudPrimaryProviderURI");

	print PRI "[$cloud]\n";
	print PRI "comment = $comment\n";
	print PRI "read only = no\n";
	print PRI "locking = no\n";
	print PRI "path = /export/private/$cloud\n";
	print PRI "guest ok = no\n";
	print PRI "create mask = 0640\n";
	print PRI "directory mask = 0770\n";
	print PRI "valid users = \@$cloud\n";
	print PRI "read list = \@$cloud\n";
	print PRI "write list = \@$cloud\n";
	#print PRI "admin users = $owner\n";
	print PRI "force user = $owner\n" if ( "%CloudBox{cloudbox.network.private_force_user}%" eq "yes" );
	print PRI "force group = $cloud\n";
	print PRI "force create mode = 0640\n";
	print PRI "force directory mode = 0770\n";
	print PRI "vfs objects = full_audit\n";
	print PRI "root preexec = /etc/idc_services connect $data_box private $cloud $owner\n" unless "$data_box" eq "$hostID";
	if ( "%CloudBox{cloudbox.samba.auto}%" eq "yes" ) {
	    print AUT "/bin/echo \"Checking and mounting private $cloud cloud...\"\n" unless "$data_box" eq "$hostID";
	    print AUT "/etc/idc_services connect $data_box private $cloud $owner\n" unless "$data_box" eq "$hostID";
	}
	print PRI "root postexec = /etc/idc_services disconnect $data_box private $cloud $owner\n" unless "$data_box" eq "$hostID";
	print PRI "\n";
    }
    close(PRI);
}

# Checking Public Clouds
my $pubfilter = "(&(iDCloudStatus=Public)(bounceadmin=$sambaDomain)(|(iDCloudPrimaryType=Storage)(iDCloudPrimaryType=DigitalContents)))";
my $public_clouds = "%CloudBox{cloudbox.network.public_clouds}%";
if ( $public_clouds ne "" ) {
    my @public_clouds_list = split(/,/,$public_clouds);
    my @pubcl;
    foreach my $cl (@public_clouds_list) {
	push(@pubcl,"(cn=$cl)");
    }
    my $pubflt_cl = "|";
    foreach my $fcl (@pubcl) {
	$pubflt_cl .= $fcl;
    }
    $pubfilter = "(&(iDCloudStatus=Public)($pubflt_cl)(bounceadmin=$sambaDomain)(|(iDCloudPrimaryType=Storage)(iDCloudPrimaryType=DigitalContents)))";
}

my $pubattrs = ["cn","iDCloudName","gidNumber","iDCloudPrimaryType","iDCloudPrimaryMember","iDCloudSecondaryMember","iDCloudPrimaryProviderURI"];
$mesg = $ldap -> search(
    base => $grpbase,
    scope => "one",
    filter => $pubfilter,
    attrs => $pubattrs
);

$mesg -> code && die $mesg -> error;
my @pubentries = $mesg -> all_entries;

# Making SMB Public Clouds
if ( "%CloudBox{cloudbox.network.samba_server}%" eq "yes" ) {
    open(PUB,"> /etc/samba/public.conf");
    foreach my $entry (@pubentries) {
	my $cloud = $entry -> get_value("cn");
	my $comment = $entry -> get_value("iDCloudName");
	my $owner = $entry -> get_value("iDCloudPrimaryMember");
	my $data_box = $entry -> get_value("iDCloudPrimaryProviderURI");
	my $data_ip = $box_ips{$data_box};
	my @data_types = $entry -> get_value("iDCloudSecondaryType");
	my $data_type;
	my @readers = $entry -> get_value("iDCloudSecondaryMember");
	my @readgroup;
	push(@readgroup,$owner);
	foreach my $type (@data_types) {
	    if ( $type eq "DigitalContents" ) {
		$data_type = "DigitalContents";
		push(@readgroup,"\@apache");
	    }
	}
	foreach my $rg (@readers) {
	    push(@readgroup,"\@$rg"); 
	}
	my $read_gp = join(",",@readgroup);
	print PUB "[$cloud]\n";
	print PUB "comment = $comment\n";
	print PUB "read only = no\n";
	print PUB "locking = no\n";
	print PUB "path = /export/public/$cloud\n";
	print PUB "guest ok = no\n";
	print PUB "create mask = 0664\n";
	print PUB "directory mask = 0775\n";
	if ( $data_type eq "DigitalContents" ) {
	    print PUB "valid users = \@$cloud,$read_gp,$owner,local\n";
	    print PUB "read list = \@$cloud,$read_gp,$owner,local\n";
	    print PUB "write list = \@$cloud,$owner,local\n";
	    #print PUB "force user = local\n";
	} else {
	    print PUB "valid users = \@$cloud,$read_gp,$owner\n";
	    print PUB "read list = \@$cloud,$read_gp,$owner\n";
	    print PUB "write list = \@$cloud,$owner\n";
	    #print PUB "force user = $owner\n";
	}
	print PUB "force group = $cloud\n";
	#print PUB "admin users = $owner\n";
	print PUB "force create mode = 0664\n";
	print PUB "force directory mode = 0775\n";
	print PUB "vfs objects = full_audit\n";
	print PUB "root preexec = /etc/idc_services connect $data_box public $cloud $owner\n" unless "$data_box" eq "$hostID";
	if ( "%CloudBox{cloudbox.samba.auto}%" eq "yes" ) {
	    print AUT "/bin/echo \"Checking and mounting public $cloud cloud...\"\n" unless "$data_box" eq "$hostID";
	    print AUT "/etc/idc_services connect $data_box public $cloud $owner\n" unless "$data_box" eq "$hostID";
	}
	print PUB "root postexec = /etc/idc_services disconnect $data_box public $cloud $owner\n" unless "$data_box" eq "$hostID";
	print PUB "\n";
    }
    close(PUB);
}

if ( "%CloudBox{cloudbox.samba.auto}%" eq "yes" ) {
    close(AUT);
    system("/bin/chmod 0755 /etc/idc_samba_auto");
}
$mesg = $ldap -> unbind;
exit 0;
